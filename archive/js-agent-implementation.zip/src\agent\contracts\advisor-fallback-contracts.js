function createAdvisorFallbackDecision(input) {
  return {
    layer: "advisor",
    decision: input.decision,
    message: input.message,
    source: input.source || "graph",
    retryable: Boolean(input.retryable),
    graphError: input.graphError ?? null,
  };
}

module.exports = {
  createAdvisorFallbackDecision,
};
