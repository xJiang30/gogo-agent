function createProposalService() {
  const proposals = new Map();
  const histories = new Map();

  const allowedTransitions = new Map([
    ["pending", new Set(["accepted", "rejected", "expired", "conflicted"])],
    ["accepted", new Set()],
    ["rejected", new Set()],
    ["expired", new Set()],
    ["conflicted", new Set()],
  ]);

  return {
    persistProposal(proposal, context) {
      const currentVersion = context.currentTripVersion;
      const nextStatus = proposal.baseVersion === currentVersion ? "pending" : "conflicted";
      const stored = { ...proposal, status: nextStatus };
      proposals.set(stored.proposalId, stored);
      histories.set(stored.proposalId, [
        createHistoryEntry({
          fromStatus: null,
          toStatus: nextStatus,
        }),
      ]);
      return stored;
    },

    getProposal(proposalId) {
      return proposals.get(proposalId) || null;
    },

    listProposals() {
      return Array.from(proposals.values());
    },

    updateProposalStatus(proposalId, status) {
      const current = proposals.get(proposalId);
      if (!current) return null;
      if (!canTransition(allowedTransitions, current.status, status)) {
        return null;
      }

      const updated = { ...current, status };
      proposals.set(proposalId, updated);
      const history = histories.get(proposalId) || [];
      history.push(
        createHistoryEntry({
          fromStatus: current.status,
          toStatus: status,
        }),
      );
      histories.set(proposalId, history);
      return updated;
    },

    getProposalHistory(proposalId) {
      return histories.get(proposalId) || [];
    },
  };
}

function canTransition(allowedTransitions, fromStatus, toStatus) {
  if (fromStatus === toStatus) {
    return true;
  }

  const nextStatuses = allowedTransitions.get(fromStatus);
  return Boolean(nextStatuses && nextStatuses.has(toStatus));
}

function createHistoryEntry(input) {
  return {
    fromStatus: input.fromStatus,
    toStatus: input.toStatus,
    changedAt: new Date().toISOString(),
  };
}

module.exports = {
  createProposalService,
};
