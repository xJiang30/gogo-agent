const {
  createResearchSuccess,
  createResearchDegraded,
  createResearchFailure,
} = require("../../contracts/research-outcome-contracts.js");
const {
  createGraphErrorEnvelope,
} = require("../../contracts/graph-error-envelope-contracts.js");

async function runResearchStep({ domain, brief, specialist, classifyFailure }) {
  try {
    const result = await specialist.research(brief);
    if ((result.evidence || []).length === 0 || (result.confidence ?? 0) < 0.5) {
      return {
        outcome: createResearchDegraded({
          domain,
          result,
          reason: "low_confidence_or_missing_evidence",
        }),
        graphError: null,
      };
    }

    return {
      outcome: createResearchSuccess({ domain, result }),
      graphError: null,
    };
  } catch (error) {
    const failure = classifyFailure(error);
    const decision = failure.action === "fail_fast" ? "fail_run" : "retry_later";

    return {
      outcome: createResearchFailure({
        domain,
        reason: failure.reason,
        retryable: failure.retryable,
        errorCode: failure.errorCode,
      }),
      graphError: createGraphErrorEnvelope({
        decision,
        retryable: failure.retryable,
        errorCode: failure.errorCode,
        failedDomains: [domain],
        message: failure.reason,
        providerStatus: error.status ?? null,
      }),
    };
  }
}

module.exports = {
  runResearchStep,
};
