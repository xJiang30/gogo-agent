const { createPlanCandidate } = require("../../contracts/trip-planning-graph-state-contracts.js");

function mergeCandidatesNode(state) {
  const affectedDayIds = state.planningBrief.affectedDayIds || [];
  const stay = state.stayOutcome?.result;
  const mobility = state.mobilityOutcome?.result;
  const experience = state.experienceOutcome?.result;
  const warnings = [];

  if (state.mobilityOutcome?.status === "failed") {
    warnings.push("mobility research unavailable");
  }

  if (state.experienceOutcome?.status === "degraded") {
    warnings.push("experience evidence is incomplete");
  }

  const score =
    (stay?.confidence ?? 0) +
    (mobility?.confidence ?? 0) +
    (experience?.confidence ?? 0);
  const evidence = [
    ...(stay?.evidence || []),
    ...(mobility?.evidence || []),
    ...(experience?.evidence || []),
  ];
  const missingInfo = [
    ...(stay?.missingInfo || []),
    ...(mobility?.missingInfo || []),
    ...(experience?.missingInfo || []),
  ];
  const variants = buildInitialPlanVariants({ stay, mobility, experience });
  const candidates =
    state.mode === "initial_plan"
      ? variants.map((variant, index) =>
          createPlanCandidate({
            candidateId: `candidate-${index + 1}`,
            title: variant.title,
            theme: variant.theme,
            summary: variant.summary,
            dayFrames: state.skeletonPlan.dayFrames,
            stayChoices: variant.stayChoices,
            mobilityChoices: variant.mobilityChoices,
            experienceChoices: variant.experienceChoices,
            stayPlan: variant.stayPlan,
            mobilityPlan: variant.mobilityPlan,
            foodPlan: variant.foodPlan,
            dayPlans: variant.dayPlans,
            bestFor: variant.bestFor,
            tradeoffs: variant.tradeoffs,
            reasons: variant.reasons,
            risks: variant.risks,
            score: Math.max(score - index * 0.1, 0),
            evidence,
            warnings,
            missingInfo,
          }),
        )
      : [
          createPlanCandidate({
            candidateId: "candidate-replan-1",
            title: "Rebalance affected days",
            theme: "cross-day repair",
            summary: [stay?.summary, mobility?.summary, experience?.summary]
              .filter(Boolean)
              .join(" "),
            dayFrames: state.skeletonPlan.dayFrames,
            stayChoices: stay?.options || [],
            mobilityChoices: mobility?.options || [],
            experienceChoices: experience?.options || [],
            reasons: ["Cross-day repair needed", "Built from currently usable research outputs"],
            risks: affectedDayIds.length > 1 ? ["Touches multiple days"] : [],
            score,
            evidence,
            warnings,
            missingInfo,
          }),
        ];

  return {
    ...state,
    mergedCandidates: candidates,
    trace: state.trace.concat({ node: "merge_candidates_node" }),
  };
}

function buildInitialPlanVariants({ stay, mobility, experience }) {
  const stayOptions = stay?.options || [];
  const mobilityOptions = mobility?.options || [];
  const experienceOptions = experience?.options || [];
  const baseSummary = [stay?.summary, mobility?.summary, experience?.summary]
    .filter(Boolean)
    .join(" ");

  return [0, 1, 2].map((index) => {
    const stayChoice = pickOption(stayOptions, index);
    const mobilityChoice = pickOption(mobilityOptions, index);
    const experienceChoice = pickOption(experienceOptions, index);
    const title = buildCandidateTitle({
      stayChoice,
      mobilityChoice,
      experienceChoice,
      fallback: `Planning option ${index + 1}`,
    });

    return {
      title,
      theme: buildTheme({ stayChoice, mobilityChoice, experienceChoice }),
      summary: baseSummary || title,
      stayChoices: stayChoice ? [stayChoice] : stayOptions,
      mobilityChoices: mobilityChoice ? [mobilityChoice] : mobilityOptions,
      experienceChoices: experienceChoice ? [experienceChoice] : experienceOptions,
      stayPlan: buildStayPlan(stayChoice),
      mobilityPlan: buildMobilityPlan(mobilityChoice),
      foodPlan: buildFoodPlan(experienceChoice),
      dayPlans: buildDayPlans({
        stayChoice,
        mobilityChoice,
        experienceChoice,
        planningSummary: baseSummary || title,
      }),
      bestFor: ["First-pass trip comparison", "Editable Trip Board draft"],
      tradeoffs: ["Needs dates, budget, and traveler details before booking"],
      reasons: [
        stayChoice ? `Stay: ${getOptionTitle(stayChoice)}` : null,
        mobilityChoice ? `Mobility: ${getOptionTitle(mobilityChoice)}` : null,
        experienceChoice ? `Experience: ${getOptionTitle(experienceChoice)}` : null,
      ].filter(Boolean),
      risks: [],
    };
  });
}

function buildStayPlan(stayChoice) {
  const title = getOptionTitle(stayChoice) || "Central stay anchor";
  return {
    anchorArea: title,
    nights: null,
    rationale: getOptionText(stayChoice, "rationale") || "Use one primary stay anchor to reduce transfer friction.",
    hotelSwitches: 0,
  };
}

function buildMobilityPlan(mobilityChoice) {
  const title = getOptionTitle(mobilityChoice) || "Nearby day trip";
  return {
    dayTrip: {
      destination: title,
      transport: getOptionText(mobilityChoice, "transport") || "train or local transit",
      estimatedOneWayTime: getOptionText(mobilityChoice, "estimatedOneWayTime") || null,
      transferPressure: getOptionText(mobilityChoice, "transferPressure") || "unknown",
      rationale:
        getOptionText(mobilityChoice, "rationale") ||
        getOptionText(mobilityChoice, "mobilityNotes") ||
        "Keep the day trip reachable from the primary city anchor.",
    },
  };
}

function buildFoodPlan(experienceChoice) {
  const title = getOptionTitle(experienceChoice) || "Local food focus";
  return {
    mustTry: [title],
    suggestedAreas: [],
    reservationNotes: [],
  };
}

function buildDayPlans({ stayChoice, mobilityChoice, experienceChoice, planningSummary }) {
  const stayTitle = getOptionTitle(stayChoice) || "central stay";
  const mobilityTitle = getOptionTitle(mobilityChoice) || "nearby day trip";
  const experienceTitle = getOptionTitle(experienceChoice) || "local food and experience";

  return [
    {
      day: 1,
      title: "Arrival and local food",
      area: stayTitle,
      pace: "light",
      blocks: [
        {
          timeOfDay: "afternoon",
          type: "arrival",
          title: `Arrive and settle near ${stayTitle}`,
          location: stayTitle,
          duration: "1-2 hours",
          rationale: "Keep the first day light and protect energy for the rest of the trip.",
        },
        {
          timeOfDay: "evening",
          type: "meal",
          title: experienceTitle,
          location: stayTitle,
          duration: "1-2 hours",
          rationale: planningSummary,
        },
      ],
    },
    {
      day: 2,
      title: "Nearby day trip",
      area: mobilityTitle,
      pace: "moderate",
      blocks: [
        {
          timeOfDay: "daytime",
          type: "day_trip",
          title: mobilityTitle,
          location: mobilityTitle,
          duration: "half day to full day",
          rationale: getOptionText(mobilityChoice, "rationale") || getOptionText(mobilityChoice, "mobilityNotes"),
        },
      ],
    },
    {
      day: 3,
      title: "City food and flexible wrap-up",
      area: stayTitle,
      pace: "light",
      blocks: [
        {
          timeOfDay: "morning",
          type: "experience",
          title: experienceTitle,
          location: stayTitle,
          duration: "2-3 hours",
          rationale: "Leave enough buffer for meals, shopping, airport transfer, or weather changes.",
        },
      ],
    },
  ];
}

function pickOption(options, index) {
  if (options.length === 0) {
    return null;
  }

  return options[index % options.length];
}

function buildCandidateTitle({ stayChoice, mobilityChoice, experienceChoice, fallback }) {
  const parts = [
    getOptionTitle(stayChoice),
    getOptionTitle(experienceChoice),
    getOptionTitle(mobilityChoice),
  ]
    .filter(Boolean)
    .slice(0, 2);

  return parts.length ? parts.join(" + ") : fallback;
}

function buildTheme({ stayChoice, mobilityChoice, experienceChoice }) {
  return [
    getOptionTitle(stayChoice),
    getOptionTitle(mobilityChoice),
    getOptionTitle(experienceChoice),
  ]
    .filter(Boolean)
    .join(" / ");
}

function getOptionTitle(option) {
  if (!option) {
    return null;
  }

  return option.title || option.label || option.name || option.id || null;
}

function getOptionText(option, field) {
  const value = option?.[field];
  return typeof value === "string" ? value : null;
}

module.exports = {
  mergeCandidatesNode,
};
