const { LlmProviderError } = require("../../src/agent/providers/provider-errors.js");

function createFakeResearchProvider(mode = "happy_path") {
  return {
    async generateResearch(input) {
      if (mode === "timeout" && input.domain === "mobility") {
        throw new LlmProviderError({
          code: "timeout_error",
          message: "timed out",
          retryable: true,
          status: 429,
        });
      }

      if (mode === "weak_evidence" && input.domain === "experience") {
        return {
          summary: `summary-${input.domain}`,
          options: buildOptions(input.domain),
          warnings: [],
          missingInfo: ["opening hours"],
          evidence: [],
          assumptions: [`assumption-${input.domain}`],
          confidence: 0.4,
        };
      }

      return {
        summary: `summary-${input.domain}`,
        options: buildOptions(input.domain),
        warnings: [],
        missingInfo: [],
        evidence: [`evidence-${input.domain}`],
        assumptions: [`assumption-${input.domain}`],
        confidence: 0.8,
      };
    },
  };
}

function buildOptions(domain) {
  if (domain === "stay") {
    return [
      { id: "stay-1", title: "Keep Hakata anchor" },
      { id: "stay-2", title: "Shift one night near transfer" },
    ];
  }

  if (domain === "mobility") {
    return [
      { id: "mobility-1", title: "Keep current train with more buffer" },
      { id: "mobility-2", title: "Move transfer later" },
    ];
  }

  return [
    { id: "experience-1", title: "Trim one dense city block" },
    { id: "experience-2", title: "Keep activity but start slower next day" },
  ];
}

module.exports = {
  createFakeResearchProvider,
};
