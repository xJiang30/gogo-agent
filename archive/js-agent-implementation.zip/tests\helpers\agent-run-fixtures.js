const {
  createTripPlanningGraphV2,
} = require("../../src/agent/graphs/trip-planning-graph-v2.js");
const { createFakeResearchProvider } = require("./fake-research-provider.js");

function createTrip() {
  return {
    id: "trip-1",
    version: 3,
    days: [
      {
        id: "day-2",
        nodes: [{ id: "hotel-1", type: "hotel", title: "Hotel Vista Hakata" }],
      },
      {
        id: "day-3",
        nodes: [{ id: "train-1", type: "transport", title: "Yufuin no Mori" }],
      },
    ],
  };
}

function buildHappyPathDeps() {
  return {
    graph: createTripPlanningGraphV2({
      researchProvider: createFakeResearchProvider(),
    }),
  };
}

function buildTimeoutDeps() {
  return {
    graph: createTripPlanningGraphV2({
      researchProvider: createFakeResearchProvider("timeout"),
    }),
  };
}

function buildLocalReplaceCommand() {
  return {
    userId: "user-1",
    trip: createTrip(),
    discussionId: "discussion-local",
    userMessage: "Replace this hotel with a cheaper one nearby.",
    intent: {
      kind: "replace",
      scope: "node",
      nodeId: "hotel-1",
      replacementType: "hotel",
      affectedDayIds: ["day-2"],
    },
  };
}

function buildCrossDayReplanCommand() {
  return {
    userId: "user-1",
    trip: createTrip(),
    discussionId: "discussion-replan",
    userMessage: "Move the stay anchor and push the Yufuin day later.",
    intent: {
      kind: "replan",
      scope: "trip",
      affectedDayIds: ["day-2", "day-3"],
      requiresStayReorder: true,
      canCloseLocally: false,
      breaksMultiDayConstraints: true,
    },
  };
}

module.exports = {
  buildHappyPathDeps,
  buildTimeoutDeps,
  buildLocalReplaceCommand,
  buildCrossDayReplanCommand,
};
