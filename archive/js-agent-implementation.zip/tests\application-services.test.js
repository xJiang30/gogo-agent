const test = require("node:test");
const assert = require("node:assert/strict");

const {
  createAgentApplicationServices,
} = require("../src/application/agent-application-services.js");
const { createTripPlanningGraphV2 } = require("../src/agent/graphs/trip-planning-graph-v2.js");
const { createFakeResearchProvider } = require("./helpers/fake-research-provider.js");

function createTrip() {
  return {
    id: "trip-1",
    version: 3,
    days: [
      {
        id: "day-2",
        nodes: [{ id: "hotel-1", type: "hotel", title: "Hotel Vista Hakata" }],
      },
      {
        id: "day-3",
        nodes: [{ id: "train-1", type: "transport", title: "Yufuin no Mori" }],
      },
    ],
  };
}

function createServices() {
  return createAgentApplicationServices({
    graph: createTripPlanningGraphV2({
      researchProvider: createFakeResearchProvider(),
    }),
  });
}

test("startInitialPlanRun returns an accepted run with recommendation_set output", async () => {
  const services = createServices();

  const result = await services.startInitialPlanRun({
    userId: "user-1",
    conversationId: "conv-1",
    userMessage: "Plan a relaxed 5-day Kyushu trip with onsen and good food.",
  });

  assert.equal(result.kind, "agent_run_accepted");
  assert.equal(result.run.mode, "initial_plan");
  assert.equal(result.output.kind, "recommendation_set");
  assert.equal(result.output.recommendationSet.recommendations.length, 3);
});

test("handleDiscussionTurn returns a local proposal for a single-node replacement", async () => {
  const services = createServices();

  const result = await services.handleDiscussionTurn({
    userId: "user-1",
    trip: createTrip(),
    discussionId: "discussion-1",
    userMessage: "Replace this hotel with a cheaper one nearby.",
    intent: {
      kind: "replace",
      scope: "node",
      nodeId: "hotel-1",
      replacementType: "hotel",
      affectedDayIds: ["day-2"],
    },
  });

  assert.equal(result.kind, "agent_run_accepted");
  assert.equal(result.run.mode, "discussion_turn");
  assert.equal(result.output.kind, "proposal");
  assert.equal(result.output.proposal.status, "pending");
});

test("handleDiscussionTurn escalates to graph replan for cross-day changes", async () => {
  const services = createServices();

  const result = await services.handleDiscussionTurn({
    userId: "user-1",
    trip: createTrip(),
    discussionId: "discussion-2",
    userMessage: "Move the stay anchor and push the Yufuin day later.",
    intent: {
      kind: "replan",
      scope: "trip",
      affectedDayIds: ["day-2", "day-3"],
      requiresStayReorder: true,
      canCloseLocally: false,
      breaksMultiDayConstraints: true,
    },
  });

  assert.equal(result.kind, "agent_run_accepted");
  assert.equal(result.output.kind, "proposal");
  assert.equal(result.output.routing.decision, "graph_replan");
});

test("handleDiscussionTurn surfaces advisor fallback when graph asks for retry later", async () => {
  const services = createAgentApplicationServices({
    graph: {
      async run() {
        return {
          kind: "graph_error",
          graphError: {
            layer: "graph",
            decision: "retry_later",
            retryable: true,
            errorCode: "timeout_error",
            failedDomains: ["mobility"],
            message: "provider_timeout",
            providerStatus: 429,
          },
          trace: [],
        };
      },
    },
  });

  const result = await services.handleDiscussionTurn({
    userId: "user-1",
    trip: createTrip(),
    discussionId: "discussion-fallback",
    userMessage: "Move the stay anchor and push the Yufuin day later.",
    intent: {
      kind: "replan",
      scope: "trip",
      affectedDayIds: ["day-2", "day-3"],
      requiresStayReorder: true,
      canCloseLocally: false,
      breaksMultiDayConstraints: true,
    },
  });

  assert.equal(result.kind, "agent_run_accepted");
  assert.equal(result.output.kind, "answer");
  assert.equal(result.output.fallback.decision, "ask_retry_later");
});

test("executeProposal applies an accepted proposal through the application service", async () => {
  const services = createServices();
  const trip = createTrip();

  const proposalRun = await services.handleDiscussionTurn({
    userId: "user-1",
    trip,
    discussionId: "discussion-3",
    userMessage: "Replace this hotel with a cheaper one nearby.",
    intent: {
      kind: "replace",
      scope: "node",
      nodeId: "hotel-1",
      replacementType: "hotel",
      affectedDayIds: ["day-2"],
    },
  });

  services.setProposalStatus(proposalRun.output.proposal.proposalId, "accepted");

  const execution = await services.executeProposal({
    trip,
    proposalId: proposalRun.output.proposal.proposalId,
  });

  assert.equal(execution.kind, "execution");
  assert.equal(execution.trip.version, 4);
});
