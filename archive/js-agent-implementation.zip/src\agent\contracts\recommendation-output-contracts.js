const { createValidationResult } = require("./candidate-validation-contracts.js");

function createRecommendationSet(input) {
  return {
    type: "recommendation_set",
    version: input.version || "1.0",
    tripIntent: input.tripIntent || null,
    recommendations: input.recommendations || [],
  };
}

function createTravelPlanRecommendation(input) {
  return {
    id: input.id,
    title: input.title,
    theme: input.theme,
    summary: input.summary,
    bestFor: input.bestFor || [],
    tradeoffs: input.tradeoffs || [],
    confidence: input.confidence ?? null,
    stayPlan: input.stayPlan || null,
    dayPlans: input.dayPlans || [],
    mobilityPlan: input.mobilityPlan || null,
    foodPlan: input.foodPlan || null,
    evidence: input.evidence || [],
    missingInfo: input.missingInfo || [],
    warnings: input.warnings || [],
    source: input.source || "trip_planning_graph_v2",
    score: input.score ?? 0,
  };
}

module.exports = {
  createValidationResult,
  createRecommendationSet,
  createTravelPlanRecommendation,
};
