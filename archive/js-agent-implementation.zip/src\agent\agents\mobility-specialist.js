const { createResearchResult } = require("../contracts/specialist-research-contracts.js");
const { createDefaultResearchProvider } = require("../providers/llm-provider.js");

function createMobilitySpecialist(deps = {}) {
  const provider = deps.provider || createDefaultResearchProvider(deps);

  return {
    async research(brief) {
      const payload = await provider.generateResearch({
        domain: "mobility",
        systemPrompt: "You are the mobility specialist for a trip-planning agent. Return only JSON.",
        userPrompt: buildMobilityPrompt(brief),
      });

      return createResearchResult({
        domain: "mobility",
        ...payload,
      });
    },
  };
}

function buildMobilityPrompt(brief) {
  return [
    "Analyze mobility and transfer strategy for this trip planning request.",
    "Focus on train timing, transfer pressure, pacing, and cross-day movement risk.",
    `Mode: ${brief.mode}`,
    `Max options: ${brief.maxOptions || 3}`,
    `Planning brief: ${JSON.stringify(brief.planningBrief)}`,
    `Skeleton plan: ${JSON.stringify(brief.skeletonPlan)}`,
    `Trip snapshot: ${JSON.stringify(brief.tripSnapshot)}`,
    `Constraints: ${JSON.stringify(brief.constraints || [])}`,
    "Return JSON with fields: summary, options, warnings, missingInfo, evidence, assumptions, confidence.",
  ].join("\n");
}

module.exports = {
  createMobilitySpecialist,
};
