const { createTripProposal } = require("./contracts/routing-and-proposal-contracts.js");

function createLightweightFlows() {
  const metrics = {
    directAnswerCount: 0,
    lightweightResearchCount: 0,
    localProposalCount: 0,
  };

  return {
    answer(request) {
      metrics.directAnswerCount += 1;
      return {
        kind: "answer",
        text: `Direct answer for: ${request.userMessage}`,
      };
    },

    research(request) {
      metrics.lightweightResearchCount += 1;
      return {
        kind: "answer",
        text: `Lightweight research result for: ${request.userMessage}`,
      };
    },

    localProposal(request) {
      metrics.localProposalCount += 1;
      const trip = request.trip;
      const node = findNode(trip, request.intent.nodeId);
      const replacementTitle = buildReplacementTitle(node, request.intent.replacementType);

      return {
        kind: "proposal",
        proposal: createTripProposal({
          proposalId: request.proposalId,
          tripId: trip.id,
          baseVersion: trip.version,
          scope: request.intent.scope || "node",
          title: `Local proposal: replace ${node.title}`,
          summary: `Use ${replacementTitle} instead of ${node.title}.`,
          reasons: ["Local replacement can be closed without graph replanning."],
          warnings: [],
          operations: [
            {
              type: "ReplaceNode",
              dayId: findDayId(trip, node.id),
              nodeId: node.id,
              replacement: {
                ...node,
                title: replacementTitle,
                detail: `Suggested replacement for ${node.title}.`,
              },
            },
          ],
          impact: {
            affectedDayIds: request.intent.affectedDayIds || [],
            requiresRecalcSegmentIds: [],
          },
          evidence: [],
        }),
      };
    },

    getMetrics() {
      return { ...metrics };
    },
  };
}

function findNode(trip, nodeId) {
  for (const day of trip.days) {
    const node = day.nodes.find((item) => item.id === nodeId);
    if (node) return node;
  }
  throw new Error(`Node ${nodeId} not found`);
}

function findDayId(trip, nodeId) {
  for (const day of trip.days) {
    if (day.nodes.some((item) => item.id === nodeId)) return day.id;
  }
  throw new Error(`Day for node ${nodeId} not found`);
}

function buildReplacementTitle(node, replacementType) {
  if (replacementType === "hotel" || node.type === "hotel") {
    return "Budget Hakata Hotel";
  }

  if (replacementType === "transport" || node.type === "transport") {
    return "Later Yufuin Train";
  }

  return `Alternative ${node.title}`;
}

module.exports = {
  createLightweightFlows,
};
