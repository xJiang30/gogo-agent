function createRunMetadata(input) {
  return {
    runId: input.runId,
    mode: input.mode,
    userId: input.userId,
    conversationId: input.conversationId ?? null,
    discussionId: input.discussionId ?? null,
    tripId: input.tripId ?? null,
    status: input.status || "accepted",
    startedAt: input.startedAt || new Date().toISOString(),
  };
}

function createAgentRunAccepted(input) {
  return {
    kind: "agent_run_accepted",
    run: input.run,
    output: input.output,
  };
}

function createRunEvent(input) {
  return {
    eventId: input.eventId,
    runId: input.runId,
    type: input.type,
    timestamp: input.timestamp || new Date().toISOString(),
    payload: input.payload || {},
  };
}

function createNodeStartedEvent(input) {
  return createRunEvent({
    eventId: input.eventId,
    runId: input.runId,
    type: "run.node.started",
    payload: {
      node: input.node,
    },
  });
}

function createNodeCompletedEvent(input) {
  return createRunEvent({
    eventId: input.eventId,
    runId: input.runId,
    type: "run.node.completed",
    payload: {
      node: input.node,
    },
  });
}

function createRecommendationReadyEvent(input) {
  return createRunEvent({
    eventId: input.eventId,
    runId: input.runId,
    type: "run.recommendation.ready",
    payload: {
      recommendationSet: input.recommendationSet,
    },
  });
}

function createProposalReadyEvent(input) {
  return createRunEvent({
    eventId: input.eventId,
    runId: input.runId,
    type: "run.proposal.ready",
    payload: {
      proposal: input.proposal,
    },
  });
}

function createRunCompletedEvent(input) {
  return createRunEvent({
    eventId: input.eventId,
    runId: input.runId,
    type: "run.completed",
    payload: {},
  });
}

module.exports = {
  createRunMetadata,
  createAgentRunAccepted,
  createRunEvent,
  createNodeStartedEvent,
  createNodeCompletedEvent,
  createRecommendationReadyEvent,
  createProposalReadyEvent,
  createRunCompletedEvent,
};
