function createResearchBrief(input) {
  return {
    briefId: input.briefId,
    domain: input.domain,
    mode: input.mode,
    planningBrief: input.planningBrief,
    skeletonPlan: input.skeletonPlan,
    tripSnapshot: input.tripSnapshot ?? null,
    constraints: input.constraints || [],
    maxOptions: input.maxOptions ?? 3,
  };
}

function createResearchResult(input) {
  return {
    domain: input.domain,
    summary: input.summary,
    options: input.options || [],
    warnings: input.warnings || [],
    missingInfo: input.missingInfo || [],
    evidence: input.evidence || [],
    assumptions: input.assumptions || [],
    confidence: input.confidence ?? null,
  };
}

module.exports = {
  createResearchBrief,
  createResearchResult,
};
