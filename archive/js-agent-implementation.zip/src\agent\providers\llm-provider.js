const { createEnvQwenConfig } = require("./env-qwen-config.js");
const { createQwenAdapter } = require("./qwen-adapter.js");

function createDefaultResearchProvider(deps = {}) {
  const env = deps.env || process.env;
  return createQwenAdapter({
    config: deps.config || createEnvQwenConfig(env),
    fetchImpl: deps.fetchImpl,
    retry: deps.retry,
    timeoutMs: deps.timeoutMs ?? readTimeoutMs(env.LLM_TIMEOUT_MS),
  });
}

function readTimeoutMs(value) {
  const timeoutMs = Number(value);
  if (Number.isFinite(timeoutMs) && timeoutMs > 0) {
    return timeoutMs;
  }

  return 60000;
}

module.exports = {
  createDefaultResearchProvider,
};
