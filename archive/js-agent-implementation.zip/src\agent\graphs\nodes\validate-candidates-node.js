const { createValidationResult } = require("../../contracts/candidate-validation-contracts.js");

function validateCandidatesNode(state) {
  const candidateResults = state.mergedCandidates.map((candidate) => {
    const failures = [];
    if ((candidate.evidence || []).length === 0) failures.push("missing_evidence");
    if ((candidate.score ?? 0) < 1.2) failures.push("low_score");

    return {
      candidateId: candidate.candidateId,
      status: failures.length === 0 ? "pass" : "fail",
      reasons: failures,
    };
  });

  return {
    ...state,
    validationResult: createValidationResult({
      candidateResults,
      overallStatus: candidateResults.some((entry) => entry.status === "pass") ? "pass" : "fail",
    }),
    trace: state.trace.concat({ node: "validate_candidates_node" }),
  };
}

module.exports = {
  validateCandidatesNode,
};
