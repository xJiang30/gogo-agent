const test = require("node:test");
const assert = require("node:assert/strict");

const { createTravelAdvisor } = require("../src/agent/travel-advisor.js");
const { createProposalService } = require("../src/agent/proposal-service.js");
const { createProposalExecutor } = require("../src/agent/proposal-executor.js");
const { createTripPlanningGraphV2 } = require("../src/agent/graphs/trip-planning-graph-v2.js");
const { createLightweightFlows } = require("../src/agent/lightweight-flows.js");
const { createFakeResearchProvider } = require("./helpers/fake-research-provider.js");

function createFixtureTrip() {
  return {
    id: "trip-1",
    version: 3,
    days: [
      {
        id: "day-2",
        nodes: [
          {
            id: "hotel-1",
            type: "hotel",
            title: "Hotel Vista Hakata",
            location: "Hakata",
            detail: "Near Hakata Station.",
          },
        ],
      },
      {
        id: "day-3",
        nodes: [
          {
            id: "train-1",
            type: "transport",
            title: "Yufuin no Mori",
            location: "Hakata -> Yufuin",
            detail: "Morning departure.",
          },
        ],
      },
    ],
  };
}

function createAdvisor() {
  const proposalService = createProposalService();
  const graph = createTripPlanningGraphV2({
    researchProvider: createFakeResearchProvider(),
  });
  const lightweightFlows = createLightweightFlows();
  const executor = createProposalExecutor();

  return {
    advisor: createTravelAdvisor({
      proposalService,
      graph,
      lightweightFlows,
      executor,
    }),
    proposalService,
    graph,
    lightweightFlows,
    executor,
  };
}

test("TravelAdvisor routes explain-style requests to direct answer", async () => {
  const { advisor } = createAdvisor();

  const result = await advisor.handleRequest({
    userId: "user-1",
    conversationId: "conv-1",
    userMessage: "为什么把酒店放在博多？",
    trip: createFixtureTrip(),
    intent: {
      kind: "ask",
      scope: "node",
      nodeId: "hotel-1",
      affectedDayIds: ["day-2"],
    },
  });

  assert.equal(result.kind, "answer");
  assert.equal(result.routing.decision, "direct_answer");
});

test("TravelAdvisor routes single-node replacement to local proposal without graph", async () => {
  const { advisor, graph, lightweightFlows } = createAdvisor();

  const result = await advisor.handleRequest({
    userId: "user-1",
    conversationId: "conv-2",
    userMessage: "把这个酒店换成附近便宜一点的",
    trip: createFixtureTrip(),
    intent: {
      kind: "replace",
      scope: "node",
      nodeId: "hotel-1",
      affectedDayIds: ["day-2"],
      replacementType: "hotel",
    },
  });

  assert.equal(result.kind, "proposal");
  assert.equal(result.routing.decision, "local_proposal");
  assert.equal(result.proposal.status, "pending");
  assert.equal(result.proposal.scope, "node");
  assert.equal(lightweightFlows.getMetrics().localProposalCount, 1);
  assert.equal(graph.getMetrics().runCount, 0);
});

test("TravelAdvisor routes cross-day change to TripPlanningGraphV2", async () => {
  const { advisor, graph, lightweightFlows } = createAdvisor();

  const result = await advisor.handleRequest({
    userId: "user-1",
    conversationId: "conv-3",
    userMessage: "把前两天的住宿都调到另一个区，并把由布院那天往后挪",
    trip: createFixtureTrip(),
    intent: {
      kind: "replan",
      scope: "trip",
      affectedDayIds: ["day-2", "day-3"],
      requiresStayReorder: true,
      canCloseLocally: false,
      breaksMultiDayConstraints: true,
    },
  });

  assert.equal(result.kind, "proposal");
  assert.equal(result.routing.decision, "graph_replan");
  assert.equal(result.proposal.status, "pending");
  assert.equal(result.proposal.scope, "trip");
  assert.equal(graph.getMetrics().runCount, 1);
  assert.equal(lightweightFlows.getMetrics().localProposalCount, 0);
});

test("TravelAdvisor converts retryable graph failure into ask_retry_later for cross-day replan", async () => {
  const proposalService = createProposalService();
  const lightweightFlows = createLightweightFlows();
  const advisor = createTravelAdvisor({
    proposalService,
    lightweightFlows,
    executor: createProposalExecutor(),
    graph: {
      async run() {
        return {
          kind: "graph_error",
          graphError: {
            layer: "graph",
            decision: "retry_later",
            retryable: true,
            errorCode: "timeout_error",
            failedDomains: ["mobility"],
            message: "provider_timeout",
            providerStatus: 429,
          },
          trace: [],
        };
      },
    },
  });

  const result = await advisor.handleRequest({
    userId: "user-1",
    conversationId: "conv-retry",
    userMessage: "鎶婂墠涓ゅぉ鐨勪綇瀹块兘璋冨埌鍙︿竴涓尯锛屽苟鎶婄敱甯冮櫌閭ｅぉ寰€鍚庢尓",
    trip: createFixtureTrip(),
    intent: {
      kind: "replan",
      scope: "trip",
      affectedDayIds: ["day-2", "day-3"],
      requiresStayReorder: true,
      canCloseLocally: false,
      breaksMultiDayConstraints: true,
    },
  });

  assert.equal(result.kind, "answer");
  assert.equal(result.fallback.decision, "ask_retry_later");
});

test("ProposalExecutor applies an accepted proposal returned by the advisor", async () => {
  const { advisor, proposalService } = createAdvisor();
  const trip = createFixtureTrip();

  const proposalResult = await advisor.handleRequest({
    userId: "user-1",
    conversationId: "conv-4",
    userMessage: "把这个酒店换成附近便宜一点的",
    trip,
    intent: {
      kind: "replace",
      scope: "node",
      nodeId: "hotel-1",
      affectedDayIds: ["day-2"],
      replacementType: "hotel",
    },
  });

  const accepted = proposalService.updateProposalStatus(
    proposalResult.proposal.proposalId,
    "accepted",
  );

  const execution = await advisor.executeProposal({
    trip,
    proposalId: accepted.proposalId,
  });

  assert.equal(execution.trip.version, 4);
  assert.notEqual(execution.trip.days[0].nodes[0].title, "Hotel Vista Hakata");
});
