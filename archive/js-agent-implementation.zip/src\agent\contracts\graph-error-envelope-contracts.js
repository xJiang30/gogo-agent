function createGraphErrorEnvelope(input) {
  return {
    layer: "graph",
    decision: input.decision,
    retryable: Boolean(input.retryable),
    errorCode: input.errorCode,
    failedDomains: input.failedDomains || [],
    message: input.message,
    providerStatus: input.providerStatus ?? null,
  };
}

module.exports = {
  createGraphErrorEnvelope,
};
