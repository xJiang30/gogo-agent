const test = require("node:test");
const assert = require("node:assert/strict");

const {
  createResearchBrief,
  createResearchResult,
} = require("../src/agent/contracts/specialist-research-contracts.js");
const {
  createResearchSuccess,
  createResearchDegraded,
  createResearchFailure,
  isResearchUsable,
} = require("../src/agent/contracts/research-outcome-contracts.js");
const {
  createAdvisorFallbackDecision,
} = require("../src/agent/contracts/advisor-fallback-contracts.js");
const {
  createValidationResult,
  createRecommendationSet,
  createTravelPlanRecommendation,
} = require("../src/agent/contracts/recommendation-output-contracts.js");
const { createPlanningBriefBuilder } = require("../src/agent/planning-brief-builder.js");
const { createTravelAdvisor } = require("../src/agent/travel-advisor.js");
const { createProposalService } = require("../src/agent/proposal-service.js");
const { createProposalExecutor } = require("../src/agent/proposal-executor.js");
const { createTripPlanningGraphV2 } = require("../src/agent/graphs/trip-planning-graph-v2.js");
const { createLightweightFlows } = require("../src/agent/lightweight-flows.js");
const { createFakeResearchProvider } = require("./helpers/fake-research-provider.js");

test("research and output contract factories produce stable shapes", () => {
  const researchBrief = createResearchBrief({
    briefId: "brief-1",
    domain: "stay",
    mode: "cross_day_replan",
    planningBrief: { mode: "cross_day_replan" },
    skeletonPlan: { tripShape: "rebalance" },
    tripSnapshot: { id: "trip-1" },
    constraints: [],
    maxOptions: 3,
  });

  const researchResult = createResearchResult({
    domain: "stay",
    summary: "Checked stay anchors.",
    options: [{ id: "stay-1", title: "Keep Hakata" }],
  });

  const validationResult = createValidationResult({
    candidateResults: [{ candidateId: "candidate-1", status: "pass" }],
    overallStatus: "pass",
  });

  const recommendation = createTravelPlanRecommendation({
    id: "r1",
    title: "Fukuoka food and day trip",
    theme: "food_day_trip",
    summary: "Stay central and take one nearby day trip.",
    stayPlan: { anchorArea: "Hakata", hotelSwitches: 0 },
    mobilityPlan: { dayTrip: { destination: "Dazaifu" } },
    foodPlan: { mustTry: ["ramen"] },
    dayPlans: [{ day: 1, title: "Arrival", blocks: [] }],
  });

  const recommendationSet = createRecommendationSet({
    tripIntent: { destination: "Fukuoka" },
    recommendations: [recommendation],
  });

  assert.equal(researchBrief.domain, "stay");
  assert.equal(researchResult.domain, "stay");
  assert.equal(validationResult.overallStatus, "pass");
  assert.equal(recommendationSet.type, "recommendation_set");
  assert.equal(recommendationSet.version, "1.0");
  assert.equal(recommendationSet.recommendations[0].stayPlan.anchorArea, "Hakata");
});

test("research outcome factories create explicit success, degraded, and failure states", () => {
  const success = createResearchSuccess({
    domain: "stay",
    result: { domain: "stay", summary: "ok", options: [] },
  });
  const degraded = createResearchDegraded({
    domain: "mobility",
    result: { domain: "mobility", summary: "partial", options: [] },
    reason: "missing_evidence",
  });
  const failure = createResearchFailure({
    domain: "experience",
    reason: "provider_timeout",
    retryable: true,
  });

  assert.equal(success.status, "success");
  assert.equal(degraded.status, "degraded");
  assert.equal(failure.status, "failed");
  assert.equal(isResearchUsable(success), true);
  assert.equal(isResearchUsable(degraded), true);
  assert.equal(isResearchUsable(failure), false);
});

test("advisor fallback decision factory produces a stable shape", () => {
  const fallback = createAdvisorFallbackDecision({
    decision: "ask_retry_later",
    message: "Retry later.",
    source: "graph",
    retryable: true,
    graphError: {
      layer: "graph",
      decision: "retry_later",
      retryable: true,
      errorCode: "timeout_error",
      failedDomains: ["mobility"],
      message: "provider_timeout",
      providerStatus: 429,
    },
  });

  assert.equal(fallback.layer, "advisor");
  assert.equal(fallback.decision, "ask_retry_later");
  assert.equal(fallback.retryable, true);
  assert.equal(fallback.graphError.errorCode, "timeout_error");
});

test("PlanningBriefBuilder normalizes a cross-day replan request before advisor routing", async () => {
  const trip = {
    id: "trip-1",
    version: 3,
    days: [
      { id: "day-2", nodes: [{ id: "hotel-1", type: "hotel", title: "Hotel Vista Hakata" }] },
      { id: "day-3", nodes: [{ id: "train-1", type: "transport", title: "Yufuin no Mori" }] },
    ],
  };

  const builder = createPlanningBriefBuilder();
  const proposalService = createProposalService();
  const advisor = createTravelAdvisor({
    proposalService,
    graph: createTripPlanningGraphV2({
      researchProvider: createFakeResearchProvider(),
    }),
    lightweightFlows: createLightweightFlows(),
    executor: createProposalExecutor(),
    planningBriefBuilder: builder,
  });

  const result = await advisor.handleRequest({
    userId: "user-1",
    conversationId: "conv-1",
    userMessage: "把前两天的住宿都调一下，再把由布院那天往后挪一点",
    trip,
    intent: {
      kind: "replan",
      scope: "trip",
      affectedDayIds: ["day-2", "day-3"],
      requiresStayReorder: true,
      canCloseLocally: false,
      breaksMultiDayConstraints: true,
    },
  });

  assert.equal(result.routing.decision, "graph_replan");
  assert.equal(result.planningBrief.mode, "cross_day_replan");
  assert.deepEqual(result.planningBrief.affectedDayIds, ["day-2", "day-3"]);
  assert.equal(result.proposal.status, "pending");
});
