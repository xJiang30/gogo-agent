const { createTripProposal } = require("../../contracts/routing-and-proposal-contracts.js");
const {
  createRecommendationSet,
  createTravelPlanRecommendation,
} = require("../../contracts/recommendation-output-contracts.js");

function finalizeOutputNode(state, proposalId, trip) {
  const chosen = chooseCandidate(state);

  if (state.mode === "initial_plan") {
    return {
      ...state,
      finalRecommendationSet: createRecommendationSet({
        tripIntent: createTripIntent(state.planningBrief),
        recommendations: state.mergedCandidates.slice(0, 3).map(toRecommendation),
      }),
      trace: state.trace.concat({ node: "finalize_output_node" }),
    };
  }

  return {
    ...state,
    finalTripProposal: createTripProposal({
      proposalId,
      tripId: trip.id,
      baseVersion: trip.version,
      scope: "trip",
      title: chosen.title,
      summary: chosen.summary,
      reasons: chosen.reasons,
      warnings: chosen.warnings,
      operations: (state.planningBrief.affectedDayIds || []).flatMap((dayId) => {
        const day = trip.days.find((item) => item.id === dayId);
        if (!day || day.nodes.length === 0) return [];
        return [
          {
            type: "UpdateNode",
            dayId,
            nodeId: day.nodes[0].id,
            patch: {
              detail: `Graph replanned this node for ${dayId}.`,
            },
          },
        ];
      }),
      impact: {
        affectedDayIds: state.planningBrief.affectedDayIds || [],
        requiresRecalcSegmentIds: [],
      },
      evidence: (chosen.evidence || []).map((item, index) => ({
        id: `${proposalId}-evidence-${index + 1}`,
        kind: "research_note",
        text: item,
      })),
    }),
    trace: state.trace.concat({ node: "finalize_output_node" }),
  };
}

function toRecommendation(candidate) {
  return createTravelPlanRecommendation({
    id: candidate.candidateId,
    title: candidate.title,
    theme: candidate.theme,
    summary: candidate.summary,
    bestFor: candidate.bestFor,
    tradeoffs: candidate.tradeoffs,
    confidence: candidate.score,
    stayPlan: candidate.stayPlan,
    dayPlans: candidate.dayPlans,
    mobilityPlan: candidate.mobilityPlan,
    foodPlan: candidate.foodPlan,
    reasons: candidate.reasons,
    risks: candidate.risks,
    evidence: candidate.evidence,
    warnings: candidate.warnings,
    missingInfo: candidate.missingInfo,
    score: candidate.score,
    source: "trip_planning_graph_v2",
  });
}

function createTripIntent(planningBrief) {
  return {
    destination: planningBrief.destinationCandidates?.[0] || null,
    durationDays: planningBrief.durationDays ?? null,
    travelerCount: planningBrief.travelerCount ?? null,
    budget: planningBrief.budget ?? null,
    pace: planningBrief.pace ?? null,
    interests: planningBrief.interests || [],
    originMessage: planningBrief.originMessage || "",
  };
}

function chooseCandidate(state) {
  const passingIds = new Set(
    (state.validationResult?.candidateResults || [])
      .filter((entry) => entry.status === "pass")
      .map((entry) => entry.candidateId),
  );

  const chosen = state.mergedCandidates
    .filter((candidate) => passingIds.has(candidate.candidateId))
    .sort((left, right) => (right.score ?? 0) - (left.score ?? 0))[0];

  if (!chosen) {
    throw new Error("graph_no_trustworthy_candidate");
  }

  return chosen;
}

module.exports = {
  finalizeOutputNode,
};
