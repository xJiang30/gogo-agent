const { EscalationDecision } = require("./contracts/routing-and-proposal-contracts.js");

function createReplanEscalationPolicy() {
  return {
    decide(input) {
      const reasons = [];
      const affectedDayIds = input.affectedDayIds || [];
      const affectedNodeIds = input.affectedNodeIds || [];

      if (input.intentKind === "initial_plan") {
        return {
          decision: EscalationDecision.GRAPH_REPLAN,
          reasons: ["Initial planning requires graph orchestration"],
          affectedDayIds,
          affectedNodeIds,
        };
      }

      if (affectedDayIds.length >= 2) {
        reasons.push("Touches multiple days");
      }

      if (input.requiresStayReorder) {
        reasons.push("Requires stay-anchor reorder");
      }

      if (input.requiresCrossCityRebuild) {
        reasons.push("Requires cross-city mobility rebuild");
      }

      if (input.breaksMultiDayConstraints) {
        reasons.push("Breaks multi-day constraints");
      }

      if (reasons.length > 0 || input.canCloseLocally === false) {
        return {
          decision: EscalationDecision.GRAPH_REPLAN,
          reasons,
          affectedDayIds,
          affectedNodeIds,
        };
      }

      if (input.intentKind === "replace") {
        return {
          decision: EscalationDecision.LOCAL_PROPOSAL,
          reasons: ["Change can be closed locally"],
          affectedDayIds,
          affectedNodeIds,
        };
      }

      if (input.intentKind === "research") {
        return {
          decision: EscalationDecision.LIGHTWEIGHT_RESEARCH,
          reasons: ["Needs provider lookup but not replanning"],
          affectedDayIds,
          affectedNodeIds,
        };
      }

      return {
        decision: EscalationDecision.DIRECT_ANSWER,
        reasons: ["Can answer directly without proposal"],
        affectedDayIds,
        affectedNodeIds,
      };
    },
  };
}

module.exports = {
  createReplanEscalationPolicy,
};
