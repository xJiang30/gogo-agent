const { createTripPlanningGraphState } = require("./trip-planning-graph-state-contracts.js");

function createPlanningBrief(input) {
  return {
    mode: input.mode,
    originMessage: input.originMessage,
    travelerCount: input.travelerCount ?? null,
    dateRange: input.dateRange ?? null,
    durationDays: input.durationDays ?? null,
    budget: input.budget ?? null,
    pace: input.pace ?? null,
    destinationCandidates: input.destinationCandidates || [],
    interests: input.interests || [],
    dislikes: input.dislikes || [],
    hardConstraints: input.hardConstraints || [],
    softPreferences: input.softPreferences || [],
    mustKeepNodes: input.mustKeepNodes || [],
    mustAvoidNodes: input.mustAvoidNodes || [],
    replanScope: input.replanScope ?? null,
    replanReason: input.replanReason ?? null,
    affectedDayIds: input.affectedDayIds || [],
  };
}

function createTripPlanningGraphRequest(input) {
  return {
    runId: input.runId,
    userId: input.userId,
    tripId: input.tripId ?? null,
    mode: input.mode,
    planningBrief: input.planningBrief,
    tripSnapshot: input.tripSnapshot ?? null,
    constraints: input.constraints || [],
    preferences: input.preferences || [],
  };
}

function createInitialGraphState(request) {
  return createTripPlanningGraphState({
    runId: request.runId,
    tripId: request.tripId,
    mode: request.mode,
    planningBrief: request.planningBrief,
    tripSnapshot: request.tripSnapshot,
  });
}

module.exports = {
  createPlanningBrief,
  createTripPlanningGraphRequest,
  createInitialGraphState,
};
