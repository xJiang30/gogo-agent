const { createResearchResult } = require("../contracts/specialist-research-contracts.js");
const { createDefaultResearchProvider } = require("../providers/llm-provider.js");

function createExperienceSpecialist(deps = {}) {
  const provider = deps.provider || createDefaultResearchProvider(deps);

  return {
    async research(brief) {
      const payload = await provider.generateResearch({
        domain: "experience",
        systemPrompt: "You are the experience specialist for a trip-planning agent. Return only JSON.",
        userPrompt: buildExperiencePrompt(brief),
      });

      return createResearchResult({
        domain: "experience",
        ...payload,
      });
    },
  };
}

function buildExperiencePrompt(brief) {
  return [
    "Analyze activity and experience balance for this trip planning request.",
    "Focus on energy pacing, attraction density, recovery windows, and day feel.",
    `Mode: ${brief.mode}`,
    `Max options: ${brief.maxOptions || 3}`,
    `Planning brief: ${JSON.stringify(brief.planningBrief)}`,
    `Skeleton plan: ${JSON.stringify(brief.skeletonPlan)}`,
    `Trip snapshot: ${JSON.stringify(brief.tripSnapshot)}`,
    `Constraints: ${JSON.stringify(brief.constraints || [])}`,
    "Return JSON with fields: summary, options, warnings, missingInfo, evidence, assumptions, confidence.",
  ].join("\n");
}

module.exports = {
  createExperienceSpecialist,
};
