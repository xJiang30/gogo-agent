const { EscalationDecision } = require("./contracts/routing-and-proposal-contracts.js");
const { createReplanEscalationPolicy } = require("./replan-escalation-policy.js");
const { createPlanningBriefBuilder } = require("./planning-brief-builder.js");
const { createAdvisorFallbackDecision } = require("./contracts/advisor-fallback-contracts.js");
const {
  createAnswerResponse,
  createProposalResponse,
  createRecommendationSetResponse,
  createExecutionResponse,
} = require("./contracts/travel-advisor-io-contracts.js");

function createTravelAdvisor(deps) {
  const policy = deps.escalationPolicy || createReplanEscalationPolicy();
  const planningBriefBuilder = deps.planningBriefBuilder || createPlanningBriefBuilder();

  return {
    async handleRequest(request) {
      const planningBrief = planningBriefBuilder.build(request);
      const routing = policy.decide({
        intentKind: normalizeIntentKind(request.intent.kind),
        affectedDayIds: request.intent.affectedDayIds || [],
        affectedNodeIds: request.intent.nodeId ? [request.intent.nodeId] : [],
        requiresStayReorder: Boolean(request.intent.requiresStayReorder),
        requiresCrossCityRebuild: Boolean(request.intent.requiresCrossCityRebuild),
        canCloseLocally: request.intent.canCloseLocally !== false,
        breaksMultiDayConstraints: Boolean(request.intent.breaksMultiDayConstraints),
      });

      if (routing.decision === EscalationDecision.DIRECT_ANSWER) {
        const answer = deps.lightweightFlows.answer(request);
        return createAnswerResponse({
          routing,
          planningBrief,
          text: answer.text,
        });
      }

      if (routing.decision === EscalationDecision.LIGHTWEIGHT_RESEARCH) {
        const answer = deps.lightweightFlows.research(request);
        return createAnswerResponse({
          routing,
          planningBrief,
          text: answer.text,
        });
      }

      const proposalId = `${routing.decision}-${Date.now()}`;

      if (routing.decision === EscalationDecision.LOCAL_PROPOSAL) {
        const result = deps.lightweightFlows.localProposal({
          ...request,
          proposalId,
        });
        const storedProposal = deps.proposalService.persistProposal(result.proposal, {
          currentTripVersion: request.trip.version,
        });
        return createProposalResponse({
          routing,
          planningBrief,
          proposal: storedProposal,
        });
      }

      const graphResult = await deps.graph.run({
        ...request,
        proposalId,
        graphRequest: {
          runId: `run-${Date.now()}`,
          userId: request.userId,
          tripId: request.trip?.id ?? null,
          mode: planningBrief.mode,
          planningBrief,
          tripSnapshot: request.trip || null,
          constraints: [],
          preferences: [],
        },
      });
      if (graphResult.kind === "graph_error") {
        const fallback = decideAdvisorFallback({ request, graphError: graphResult.graphError });

        if (
          fallback.decision === "fallback_to_answer" ||
          fallback.decision === "fallback_to_lightweight_research" ||
          fallback.decision === "ask_retry_later"
        ) {
          return createAnswerResponse({
            routing,
            planningBrief,
            text: fallback.message,
            fallback,
          });
        }

        throw new Error(fallback.message);
      }

      if (graphResult.kind === "recommendation_set") {
        return createRecommendationSetResponse({
          routing,
          planningBrief,
          recommendationSet: graphResult.recommendationSet,
          trace: graphResult.trace,
        });
      }

      const storedProposal = deps.proposalService.persistProposal(graphResult.proposal, {
        currentTripVersion: request.trip.version,
      });
      return createProposalResponse({
        routing,
        planningBrief,
        proposal: storedProposal,
      });
    },

    async executeProposal({ trip, proposalId }) {
      const proposal = deps.proposalService.getProposal(proposalId);
      if (!proposal) {
        throw new Error(`Proposal ${proposalId} not found`);
      }
      const execution = deps.executor.execute(trip, proposal);
      return createExecutionResponse(execution);
    },
  };
}

function normalizeIntentKind(kind) {
  if (kind === "initial_plan") return "initial_plan";
  if (kind === "replace") return "replace";
  if (kind === "research") return "research";
  if (kind === "replan") return "replan";
  return "ask";
}

function decideAdvisorFallback({ request, graphError }) {
  if (graphError.decision === "retry_later" && request.intent.kind === "replan") {
    return createAdvisorFallbackDecision({
      decision: "ask_retry_later",
      message: "The planning graph could not finish reliably. Please retry later.",
      retryable: true,
      graphError,
    });
  }

  if (graphError.decision === "retry_later") {
    return createAdvisorFallbackDecision({
      decision: "fallback_to_answer",
      message: "The graph timed out, so returning a safe explanatory answer instead.",
      retryable: true,
      graphError,
    });
  }

  return createAdvisorFallbackDecision({
    decision: "surface_error",
    message: "The graph failed in a way that should be surfaced to the caller.",
    retryable: false,
    graphError,
  });
}

module.exports = {
  createTravelAdvisor,
};
