function createTravelAdvisorRequest(input) {
  return {
    userId: input.userId,
    conversationId: input.conversationId,
    userMessage: input.userMessage,
    trip: input.trip ?? null,
    intent: input.intent,
  };
}

function createAnswerResponse(input) {
  return {
    kind: "answer",
    routing: input.routing,
    planningBrief: input.planningBrief,
    text: input.text,
    fallback: input.fallback ?? null,
  };
}

function createProposalResponse(input) {
  return {
    kind: "proposal",
    routing: input.routing,
    planningBrief: input.planningBrief,
    proposal: input.proposal,
  };
}

function createRecommendationSetResponse(input) {
  return {
    kind: "recommendation_set",
    routing: input.routing,
    planningBrief: input.planningBrief,
    recommendationSet: input.recommendationSet,
    trace: input.trace || [],
  };
}

function createExecutionRequest(input) {
  return {
    trip: input.trip,
    proposalId: input.proposalId,
  };
}

function createExecutionResponse(input) {
  return {
    kind: "execution",
    trip: input.trip,
    decisionLog: input.decisionLog,
  };
}

module.exports = {
  createTravelAdvisorRequest,
  createAnswerResponse,
  createProposalResponse,
  createRecommendationSetResponse,
  createExecutionRequest,
  createExecutionResponse,
};
