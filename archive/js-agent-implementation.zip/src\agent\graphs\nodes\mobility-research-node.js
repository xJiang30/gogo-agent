const { createResearchBrief } = require("../../contracts/specialist-research-contracts.js");
const { runResearchStep } = require("./run-research-step.js");

async function mobilityResearchNode(state, deps) {
  const brief = createResearchBrief({
    briefId: `${state.runId}-mobility`,
    domain: "mobility",
    mode: state.mode,
    planningBrief: state.planningBrief,
    skeletonPlan: state.skeletonPlan,
    tripSnapshot: state.tripSnapshot,
    constraints: [],
    maxOptions: 3,
  });

  const { outcome, graphError } = await runResearchStep({
    domain: "mobility",
    brief,
    specialist: deps.mobilitySpecialist,
    classifyFailure: deps.classifyProviderFailure,
  });

  return {
    ...state,
    mobilityOutcome: outcome,
    mobilityResult: outcome.result,
    graphError: graphError || state.graphError,
    trace: state.trace.concat({ node: "mobility_research_node", status: outcome.status }),
  };
}

module.exports = {
  mobilityResearchNode,
};
