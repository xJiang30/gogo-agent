const fs = require("node:fs");
const path = require("node:path");
const readline = require("node:readline/promises");
const { stdin: input, stdout: output } = require("node:process");

const {
  createAgentApplicationServices,
} = require("../src/application/agent-application-services.js");
const {
  createTripPlanningGraphV2,
} = require("../src/agent/graphs/trip-planning-graph-v2.js");
const { createDefaultResearchProvider } = require("../src/agent/providers/llm-provider.js");

const args = process.argv.slice(2);
const onceIndex = args.indexOf("--once");
const onceMessage = onceIndex >= 0 ? args[onceIndex + 1] : null;

async function main() {
  loadDotEnv(path.join(__dirname, "..", ".env"));

  const services = createServices();
  const rl = readline.createInterface({ input, output });

  printHeader();

  if (onceMessage) {
    await runOneTurn(services, onceMessage);
    rl.close();
    return;
  }

  while (true) {
    const message = await rl.question("\nSay something to the real agent. Type exit to quit.\n> ");
    const trimmed = message.trim();
    if (!trimmed || trimmed.toLowerCase() === "exit") {
      break;
    }

    await runOneTurn(services, trimmed);
  }

  rl.close();
  console.log("\nManual test ended.");
}

function createServices() {
  return createAgentApplicationServices({
    graph: createTripPlanningGraphV2({
      researchProvider: createDefaultResearchProvider(),
    }),
  });
}

async function runOneTurn(services, userMessage) {
  console.log("\nRunning the real agent. Please wait...");

  try {
    const result = await services.startInitialPlanRun({
      userId: "manual-user",
      conversationId: `manual-conversation-${Date.now()}`,
      userMessage,
    });

    printResult(result);
  } catch (error) {
    console.log("\nRun failed:");
    console.log(error && error.stack ? error.stack : String(error));
  }
}

function printHeader() {
  console.log("Gogo Agent manual end-to-end test");
  console.log("--------------------------------");
  console.log("Mode: real model only, loaded from .env");
  console.log("");
  console.log("Commands:");
  console.log("  node tests/manual-agent-e2e.js");
  console.log('  node tests/manual-agent-e2e.js --once "Plan a 3-day Fukuoka trip with food and one day trip"');
}

function printResult(result) {
  const outputResult = result.output;

  console.log("\nResult");
  console.log("--------------------------------");
  console.log(`runId: ${result.run.runId}`);
  console.log(`output kind: ${outputResult.kind}`);
  console.log(`routing decision: ${outputResult.routing?.decision || "unknown"}`);

  if (outputResult.kind === "recommendation_set") {
    console.log("\nRecommendations:");
    outputResult.recommendationSet.recommendations.forEach((item, index) => {
      console.log(`\nPlan ${index + 1}: ${item.title}${item.theme ? ` (${item.theme})` : ""}`);
      printTextBlock("Summary", item.summary);
      printStayPlan(item.stayPlan);
      printMobilityPlan(item.mobilityPlan);
      printFoodPlan(item.foodPlan);
      printDayPlans(item.dayPlans);
      printList("Best for", item.bestFor);
      printList("Tradeoffs", item.tradeoffs);
      printList("Evidence", item.evidence);
      printList("Warnings", item.warnings);
      printList("Missing info", item.missingInfo);
    });
  } else if (outputResult.kind === "proposal") {
    console.log("\nThe agent generated a pending proposal:");
    console.log(JSON.stringify(outputResult.proposal, null, 2));
  } else if (outputResult.kind === "answer") {
    console.log("\nAgent answer:");
    console.log(outputResult.text);
    if (outputResult.fallback) {
      console.log("\nNote: this used fallback, so the graph or model call did not fully complete.");
      console.log(`fallback: ${outputResult.fallback.decision}`);
      console.log(`reason: ${outputResult.fallback.graphError?.errorCode || "unknown"}`);
    }
  } else {
    console.log("\nRaw output:");
    console.log(JSON.stringify(outputResult, null, 2));
  }

  if (outputResult.trace?.length) {
    console.log("\nGraph trace:");
    for (const step of outputResult.trace) {
      console.log(`- ${step.node}${step.status ? `: ${step.status}` : ""}`);
    }
  }
}

function printTextBlock(label, value) {
  if (!value) {
    return;
  }

  console.log(`${label}: ${value}`);
}

function printChoiceList(label, choices) {
  if (!choices?.length) {
    return;
  }

  console.log(`${label}:`);
  for (const choice of choices) {
    console.log(`  - ${choice.title || choice.label || choice.name || JSON.stringify(choice)}`);
  }
}

function printStayPlan(stayPlan) {
  if (!stayPlan) {
    return;
  }

  console.log("Stay plan:");
  console.log(`  - Anchor area: ${stayPlan.anchorArea || "unknown"}`);
  console.log(`  - Hotel switches: ${stayPlan.hotelSwitches ?? "unknown"}`);
  if (stayPlan.rationale) {
    console.log(`  - Why: ${stayPlan.rationale}`);
  }
}

function printMobilityPlan(mobilityPlan) {
  if (!mobilityPlan?.dayTrip) {
    return;
  }

  console.log("Mobility plan:");
  console.log(`  - Day trip: ${mobilityPlan.dayTrip.destination || "unknown"}`);
  console.log(`  - Transport: ${mobilityPlan.dayTrip.transport || "unknown"}`);
  console.log(`  - Transfer pressure: ${mobilityPlan.dayTrip.transferPressure || "unknown"}`);
  if (mobilityPlan.dayTrip.rationale) {
    console.log(`  - Why: ${mobilityPlan.dayTrip.rationale}`);
  }
}

function printFoodPlan(foodPlan) {
  if (!foodPlan) {
    return;
  }

  printList("Food plan", foodPlan.mustTry);
}

function printDayPlans(dayPlans) {
  if (!dayPlans?.length) {
    return;
  }

  console.log("Day plans:");
  for (const day of dayPlans) {
    console.log(`  Day ${day.day}: ${day.title} (${day.pace || "unknown pace"})`);
    for (const block of day.blocks || []) {
      console.log(`    - ${block.timeOfDay}: ${block.title}`);
    }
  }
}

function printList(label, items) {
  if (!items?.length) {
    return;
  }

  console.log(`${label}:`);
  for (const item of items) {
    console.log(`  - ${item}`);
  }
}

function loadDotEnv(envPath) {
  if (!fs.existsSync(envPath)) {
    return;
  }

  const lines = fs.readFileSync(envPath, "utf8").split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) {
      continue;
    }

    const separatorIndex = trimmed.indexOf("=");
    if (separatorIndex < 0) {
      continue;
    }

    const key = trimmed.slice(0, separatorIndex).trim();
    const value = trimmed.slice(separatorIndex + 1).trim();
    if (key && !process.env[key]) {
      process.env[key] = value;
    }
  }
}

main().catch((error) => {
  console.error(error && error.stack ? error.stack : error);
  process.exit(1);
});
