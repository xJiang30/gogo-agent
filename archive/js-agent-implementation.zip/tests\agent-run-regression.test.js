const test = require("node:test");
const assert = require("node:assert/strict");

const {
  buildHappyPathDeps,
  buildTimeoutDeps,
  buildLocalReplaceCommand,
  buildCrossDayReplanCommand,
} = require("./helpers/agent-run-fixtures.js");
const {
  createAgentApplicationServices,
} = require("../src/application/agent-application-services.js");

test("agent run regression: local replace completes without graph fallback", async () => {
  const services = createAgentApplicationServices(buildHappyPathDeps());
  const result = await services.handleDiscussionTurn(buildLocalReplaceCommand());

  assert.equal(result.output.routing.decision, "local_proposal");
  assert.equal(result.output.proposal.status, "pending");
});

test("agent run regression: cross-day replan degrades safely when mobility provider times out", async () => {
  const services = createAgentApplicationServices(buildTimeoutDeps());
  const result = await services.handleDiscussionTurn(buildCrossDayReplanCommand());

  assert.equal(result.output.kind, "answer");
  assert.equal(result.output.fallback.decision, "ask_retry_later");
});
