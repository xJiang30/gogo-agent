function skeletonPlanningNode(state) {
  const affectedDayIds =
    state.planningBrief.affectedDayIds.length > 0
      ? state.planningBrief.affectedDayIds
      : (state.tripSnapshot?.days || []).map((day) => day.id);

  return {
    ...state,
    skeletonPlan: {
      tripShape: state.mode === "initial_plan" ? "multi-option discovery" : "cross-day rebalance",
      stayStrategy:
        state.mode === "initial_plan" ? "keep one primary city anchor" : "re-anchor affected stay blocks",
      mobilityStrategy: "minimize unnecessary cross-city moves",
      experienceStrategy: "keep daily intensity moderate",
      dayFrames: affectedDayIds.map((dayId, index) => ({
        dayId,
        theme: index === 0 ? "arrival-and-city" : "rebalanced-day",
      })),
    },
    trace: state.trace.concat({ node: "skeleton_planning_node" }),
  };
}

module.exports = {
  skeletonPlanningNode,
};
