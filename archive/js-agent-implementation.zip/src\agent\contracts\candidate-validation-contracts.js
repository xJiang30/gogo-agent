function createValidationResult(input) {
  return {
    candidateResults: input.candidateResults || [],
    overallStatus: input.overallStatus,
  };
}

module.exports = {
  createValidationResult,
};
