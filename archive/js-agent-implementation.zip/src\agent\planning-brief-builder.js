const { createPlanningBrief } = require("./contracts/planning-brief-and-graph-request-contracts.js");

function createPlanningBriefBuilder() {
  return {
    build(request) {
      const isInitialPlan = request.intent.kind === "initial_plan" || !request.trip;
      const isCrossDay = request.intent.kind === "replan" && !isInitialPlan;
      return createPlanningBrief({
        mode: isInitialPlan ? "initial_plan" : isCrossDay ? "cross_day_replan" : "initial_plan",
        originMessage: request.userMessage,
        destinationCandidates: request.intent.destinationCandidates || [],
        interests: request.intent.interests || [],
        dislikes: request.intent.dislikes || [],
        hardConstraints: request.intent.hardConstraints || [],
        softPreferences: request.intent.softPreferences || [],
        replanScope: request.intent.scope === "trip" ? "multi_day" : request.intent.scope || null,
        replanReason: isCrossDay ? request.userMessage : null,
        affectedDayIds: request.intent.affectedDayIds || [],
      });
    },
  };
}

module.exports = {
  createPlanningBriefBuilder,
};
