const test = require("node:test");
const assert = require("node:assert/strict");

const { createEnvQwenConfig } = require("../src/agent/providers/env-qwen-config.js");
const { createDefaultResearchProvider } = require("../src/agent/providers/llm-provider.js");
const { createQwenAdapter } = require("../src/agent/providers/qwen-adapter.js");
const { LlmProviderError } = require("../src/agent/providers/provider-errors.js");
const { classifyProviderFailure } = require("../src/agent/providers/provider-failure-policy.js");
const { createStaySpecialist } = require("../src/agent/agents/stay-specialist.js");
const { createMobilitySpecialist } = require("../src/agent/agents/mobility-specialist.js");
const { createExperienceSpecialist } = require("../src/agent/agents/experience-specialist.js");

test("createEnvQwenConfig reads the LLM env variable names", () => {
  const config = createEnvQwenConfig({
    LLM_API_KEY: "key-1",
    LLM_API_BASE: "https://dashscope.example/v1",
    LLM_MODEL_NAME: "qwen-max",
  });

  assert.deepEqual(config, {
    apiKey: "key-1",
    baseUrl: "https://dashscope.example/v1",
    modelName: "qwen-max",
  });
});

test("createDefaultResearchProvider uses LLM_TIMEOUT_MS when calling Qwen", async () => {
  const startedAt = Date.now();
  const provider = createDefaultResearchProvider({
    env: {
      LLM_API_KEY: "key-1",
      LLM_API_BASE: "https://dashscope.example/v1",
      LLM_MODEL_NAME: "qwen-plus",
      LLM_TIMEOUT_MS: "25",
    },
    retry: {
      maxRetries: 0,
      baseDelayMs: 1,
      sleepImpl: async () => {},
    },
    fetchImpl: async () => new Promise(() => {}),
  });

  await assert.rejects(
    () =>
      provider.generateResearch({
        domain: "stay",
        systemPrompt: "system",
        userPrompt: "user",
      }),
    (error) => {
      assert.equal(error.code, "timeout_error");
      return true;
    },
  );

  assert.ok(Date.now() - startedAt < 1000);
});

test("QwenAdapter calls the OpenAI-compatible chat completions endpoint and parses JSON output", async () => {
  const calls = [];
  const adapter = createQwenAdapter({
    config: {
      apiKey: "key-1",
      baseUrl: "https://dashscope.example/v1",
      modelName: "qwen-plus",
    },
    fetchImpl: async (url, options) => {
      calls.push({ url, options });
      return {
        ok: true,
        async json() {
          return {
            choices: [
              {
                message: {
                  content: JSON.stringify({
                    summary: "Keep Hakata as the main stay anchor.",
                    options: [{ id: "stay-1", title: "Keep Hakata anchor" }],
                    warnings: [],
                    missingInfo: [],
                    evidence: ["Transfer day remains manageable."],
                    assumptions: ["User prefers fewer hotel switches."],
                    confidence: 0.81,
                  }),
                },
              },
            ],
          };
        },
      };
    },
  });

  const result = await adapter.generateResearch({
    domain: "stay",
    systemPrompt: "You are a stay planning specialist.",
    userPrompt: "Suggest stay options.",
  });

  assert.equal(calls[0].url, "https://dashscope.example/v1/chat/completions");
  assert.equal(calls[0].options.method, "POST");
  assert.equal(calls[0].options.headers.Authorization, "Bearer key-1");
  assert.equal(JSON.parse(calls[0].options.body).model, "qwen-plus");
  assert.equal(result.summary, "Keep Hakata as the main stay anchor.");
  assert.equal(result.options[0].id, "stay-1");
});

test("QwenAdapter retries retryable provider errors and succeeds on a later attempt", async () => {
  let attempts = 0;
  const adapter = createQwenAdapter({
    config: {
      apiKey: "key-1",
      baseUrl: "https://dashscope.example/v1",
      modelName: "qwen-plus",
    },
    retry: {
      maxRetries: 2,
      baseDelayMs: 1,
      sleepImpl: async () => {},
    },
    fetchImpl: async () => {
      attempts += 1;
      if (attempts === 1) {
        return {
          ok: false,
          status: 429,
          async text() {
            return "rate limited";
          },
        };
      }

      return {
        ok: true,
        async json() {
          return {
            choices: [
              {
                message: {
                  content: JSON.stringify({
                    summary: "Recovered after retry.",
                    options: [{ id: "stay-1", title: "Keep Hakata anchor" }],
                  }),
                },
              },
            ],
          };
        },
      };
    },
  });

  const result = await adapter.generateResearch({
    domain: "stay",
    systemPrompt: "You are a stay planning specialist.",
    userPrompt: "Suggest stay options.",
  });

  assert.equal(attempts, 2);
  assert.equal(result.summary, "Recovered after retry.");
});

test("QwenAdapter throws config_error without retry when required config is missing", async () => {
  const adapter = createQwenAdapter({
    config: {
      apiKey: "",
      baseUrl: "https://dashscope.example/v1",
      modelName: "qwen-plus",
    },
    fetchImpl: async () => {
      throw new Error("fetch should not be called");
    },
  });

  await assert.rejects(
    () =>
      adapter.generateResearch({
        domain: "stay",
        systemPrompt: "system",
        userPrompt: "user",
      }),
    (error) => {
      assert.ok(error instanceof LlmProviderError);
      assert.equal(error.code, "config_error");
      assert.equal(error.retryable, false);
      return true;
    },
  );
});

test("QwenAdapter classifies invalid JSON content as provider_response_error", async () => {
  const adapter = createQwenAdapter({
    config: {
      apiKey: "key-1",
      baseUrl: "https://dashscope.example/v1",
      modelName: "qwen-plus",
    },
    fetchImpl: async () => ({
      ok: true,
      async json() {
        return {
          choices: [
            {
              message: {
                content: "not-json",
              },
            },
          ],
        };
      },
    }),
  });

  await assert.rejects(
    () =>
      adapter.generateResearch({
        domain: "stay",
        systemPrompt: "system",
        userPrompt: "user",
      }),
    (error) => {
      assert.ok(error instanceof LlmProviderError);
      assert.equal(error.code, "provider_response_error");
      assert.equal(error.retryable, false);
      return true;
    },
  );
});

test("QwenAdapter classifies a hung request as timeout_error", async () => {
  const adapter = createQwenAdapter({
    config: {
      apiKey: "key-1",
      baseUrl: "https://dashscope.example/v1",
      modelName: "qwen-plus",
    },
    timeoutMs: 5,
    retry: {
      maxRetries: 0,
      baseDelayMs: 1,
      sleepImpl: async () => {},
    },
    fetchImpl: async () => new Promise(() => {}),
  });

  await assert.rejects(
    () =>
      adapter.generateResearch({
        domain: "stay",
        systemPrompt: "system",
        userPrompt: "user",
      }),
    (error) => {
      assert.ok(error instanceof LlmProviderError);
      assert.equal(error.code, "timeout_error");
      assert.equal(error.retryable, true);
      return true;
    },
  );
});

test("classifyProviderFailure maps timeout and network failures to retry", () => {
  const result = classifyProviderFailure(
    new LlmProviderError({ code: "timeout_error", message: "slow", retryable: true }),
  );

  assert.equal(result.action, "retry");
  assert.equal(result.reason, "provider_timeout");
});

test("classifyProviderFailure maps invalid provider payloads to hard failure", () => {
  const result = classifyProviderFailure(
    new LlmProviderError({
      code: "provider_response_error",
      message: "bad json",
      retryable: false,
    }),
  );

  assert.equal(result.action, "fail");
  assert.equal(result.reason, "provider_untrusted_response");
});

test("specialists delegate domain research to the injected provider and preserve ResearchResult contracts", async () => {
  const callLog = [];
  const provider = {
    async generateResearch(input) {
      callLog.push(input);
      return {
        summary: `summary-${input.domain}`,
        options: [{ id: `${input.domain}-1`, title: `option-${input.domain}` }],
        warnings: [],
        missingInfo: [],
        evidence: [`evidence-${input.domain}`],
        assumptions: [`assumption-${input.domain}`],
        confidence: 0.8,
      };
    },
  };
  const brief = {
    briefId: "brief-1",
    domain: "stay",
    mode: "cross_day_replan",
    planningBrief: { affectedDayIds: ["day-1", "day-2"] },
    skeletonPlan: { dayFrames: [{ dayId: "day-1" }, { dayId: "day-2" }] },
    tripSnapshot: { id: "trip-1" },
    constraints: [],
    maxOptions: 2,
  };

  const stay = await createStaySpecialist({ provider }).research(brief);
  const mobility = await createMobilitySpecialist({ provider }).research({
    ...brief,
    domain: "mobility",
  });
  const experience = await createExperienceSpecialist({ provider }).research({
    ...brief,
    domain: "experience",
  });

  assert.deepEqual(
    callLog.map((entry) => entry.domain),
    ["stay", "mobility", "experience"],
  );
  assert.equal(stay.domain, "stay");
  assert.equal(mobility.domain, "mobility");
  assert.equal(experience.domain, "experience");
  assert.match(callLog[0].systemPrompt, /stay/i);
  assert.match(callLog[1].systemPrompt, /mobility/i);
  assert.match(callLog[2].systemPrompt, /experience/i);
});
