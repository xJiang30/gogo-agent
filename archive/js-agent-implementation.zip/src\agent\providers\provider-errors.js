class LlmProviderError extends Error {
  constructor({ code, message, retryable = false, status = null, cause = null, details = null }) {
    super(message);
    this.name = "LlmProviderError";
    this.code = code;
    this.retryable = retryable;
    this.status = status;
    this.cause = cause;
    this.details = details;
  }
}

module.exports = {
  LlmProviderError,
};
