const { createInitialGraphState } = require("../contracts/planning-brief-and-graph-request-contracts.js");
const { skeletonPlanningNode } = require("./nodes/skeleton-planning-node.js");
const { stayResearchNode } = require("./nodes/stay-research-node.js");
const { mobilityResearchNode } = require("./nodes/mobility-research-node.js");
const { experienceResearchNode } = require("./nodes/experience-research-node.js");
const { mergeCandidatesNode } = require("./nodes/merge-candidates-node.js");
const { validateCandidatesNode } = require("./nodes/validate-candidates-node.js");
const { finalizeOutputNode } = require("./nodes/finalize-output-node.js");
const { createStaySpecialist } = require("../agents/stay-specialist.js");
const { createMobilitySpecialist } = require("../agents/mobility-specialist.js");
const { createExperienceSpecialist } = require("../agents/experience-specialist.js");
const { classifyProviderFailure } = require("../providers/provider-failure-policy.js");

function createTripPlanningGraphV2(deps = {}) {
  const metrics = {
    runCount: 0,
  };
  let lastState = null;
  const graphDeps = {
    staySpecialist: deps.staySpecialist || createStaySpecialist({ provider: deps.researchProvider }),
    mobilitySpecialist: deps.mobilitySpecialist || createMobilitySpecialist({ provider: deps.researchProvider }),
    experienceSpecialist: deps.experienceSpecialist || createExperienceSpecialist({ provider: deps.researchProvider }),
    classifyProviderFailure: deps.classifyProviderFailure || classifyProviderFailure,
  };

  return {
    async run(request) {
      metrics.runCount += 1;

      const graphRequest =
        request.graphRequest ||
        {
          runId: `run-${Date.now()}`,
          tripId: request.trip?.id ?? null,
          mode: request.trip ? "cross_day_replan" : "initial_plan",
          planningBrief: {
            mode: request.trip ? "cross_day_replan" : "initial_plan",
            originMessage: request.userMessage || "",
            affectedDayIds: request.intent?.affectedDayIds || [],
          },
          tripSnapshot: request.trip || null,
          constraints: [],
          preferences: [],
        };

      let state = createInitialGraphState(graphRequest);
      state = skeletonPlanningNode(state);
      state = await stayResearchNode(state, graphDeps);
      if (state.graphError) return finishWithGraphError(state);
      state = await mobilityResearchNode(state, graphDeps);
      if (state.graphError) return finishWithGraphError(state);
      state = await experienceResearchNode(state, graphDeps);
      if (state.graphError) return finishWithGraphError(state);
      state = mergeCandidatesNode(state);
      state = validateCandidatesNode(state);
      state = finalizeOutputNode(state, request.proposalId, request.trip || request.graphRequest.tripSnapshot);
      state = {
        ...state,
        status: "completed",
      };
      lastState = state;

      if (state.mode === "initial_plan") {
        return {
          kind: "recommendation_set",
          recommendationSet: state.finalRecommendationSet,
          trace: state.trace,
        };
      }

      return {
        kind: "proposal",
        proposal: state.finalTripProposal,
        trace: state.trace,
      };
    },

    getMetrics() {
      return { ...metrics };
    },

    getLastState() {
      return lastState;
    },
  };

  function finishWithGraphError(state) {
    lastState = {
      ...state,
      status: "failed",
    };
    return {
      kind: "graph_error",
      graphError: lastState.graphError,
      trace: lastState.trace,
    };
  }
}

module.exports = {
  createTripPlanningGraphV2,
};
