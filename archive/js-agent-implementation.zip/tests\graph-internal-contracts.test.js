const test = require("node:test");
const assert = require("node:assert/strict");

const {
  createPlanCandidate,
  createTripPlanningGraphState,
} = require("../src/agent/contracts/trip-planning-graph-state-contracts.js");
const {
  createGraphErrorEnvelope,
} = require("../src/agent/contracts/graph-error-envelope-contracts.js");
const {
  createResearchSuccess,
} = require("../src/agent/contracts/research-outcome-contracts.js");
const {
  createValidationResult,
} = require("../src/agent/contracts/candidate-validation-contracts.js");
const { mergeCandidatesNode } = require("../src/agent/graphs/nodes/merge-candidates-node.js");
const { createStaySpecialist } = require("../src/agent/agents/stay-specialist.js");
const { createMobilitySpecialist } = require("../src/agent/agents/mobility-specialist.js");
const { createExperienceSpecialist } = require("../src/agent/agents/experience-specialist.js");
const { createTripPlanningGraphV2 } = require("../src/agent/graphs/trip-planning-graph-v2.js");
const {
  createPlanningBrief,
  createTripPlanningGraphRequest,
} = require("../src/agent/contracts/planning-brief-and-graph-request-contracts.js");
const { createFakeResearchProvider } = require("./helpers/fake-research-provider.js");

test("graph-internal contract factories create explicit state, candidate, and validation objects", () => {
  const candidate = createPlanCandidate({
    candidateId: "candidate-1",
    title: "Relaxed Onsen",
    theme: "low pace",
    summary: "A low-mobility Kyushu arc.",
    dayFrames: [{ dayId: "day-1", theme: "arrival" }],
    stayChoices: [{ id: "stay-1", title: "Hakata anchor" }],
    mobilityChoices: [{ id: "mobility-1", title: "Later train" }],
    experienceChoices: [{ id: "exp-1", title: "Trim one city block" }],
    reasons: ["Low stress"],
    risks: ["Requires rail timing check"],
  });

  const validation = createValidationResult({
    candidateResults: [{ candidateId: "candidate-1", status: "pass" }],
    overallStatus: "pass",
  });

  const state = createTripPlanningGraphState({
    runId: "run-1",
    tripId: "trip-1",
    mode: "cross_day_replan",
    planningBrief: { mode: "cross_day_replan" },
    tripSnapshot: { id: "trip-1" },
    stayOutcome: createResearchSuccess({
      domain: "stay",
      result: {
        domain: "stay",
        summary: "stay-ok",
        options: [{ id: "stay-1", title: "Hakata anchor" }],
      },
    }),
    graphError: createGraphErrorEnvelope({
      decision: "retry_later",
      retryable: true,
      errorCode: "timeout_error",
      failedDomains: ["mobility"],
      message: "Mobility research timed out.",
      providerStatus: 429,
    }),
  });

  assert.equal(candidate.candidateId, "candidate-1");
  assert.equal(validation.overallStatus, "pass");
  assert.equal(state.finalTripProposal, null);
  assert.deepEqual(state.mergedCandidates, []);
  assert.equal(state.stayOutcome.status, "success");
  assert.equal(state.graphError.layer, "graph");
  assert.equal(state.graphError.decision, "retry_later");
});

test("specialist agents return strict ResearchResult shapes independently of graph nodes", async () => {
  const provider = createFakeResearchProvider();
  const researchBrief = {
    briefId: "brief-1",
    domain: "stay",
    mode: "cross_day_replan",
    planningBrief: { affectedDayIds: ["day-1", "day-2"] },
    skeletonPlan: { dayFrames: [{ dayId: "day-1" }, { dayId: "day-2" }] },
    tripSnapshot: { id: "trip-1" },
    constraints: [],
    maxOptions: 3,
  };

  const stayResult = await createStaySpecialist({ provider }).research(researchBrief);
  const mobilityResult = await createMobilitySpecialist({ provider }).research({
    ...researchBrief,
    domain: "mobility",
  });
  const experienceResult = await createExperienceSpecialist({ provider }).research({
    ...researchBrief,
    domain: "experience",
  });

  assert.equal(stayResult.domain, "stay");
  assert.equal(mobilityResult.domain, "mobility");
  assert.equal(experienceResult.domain, "experience");
  assert.ok(Array.isArray(stayResult.options));
  assert.ok(Array.isArray(mobilityResult.options));
  assert.ok(Array.isArray(experienceResult.options));
});

test("TripPlanningGraphV2 delegates research nodes to extracted specialists", async () => {
  const callLog = [];
  const graph = createTripPlanningGraphV2({
    staySpecialist: {
      async research(brief) {
        callLog.push({ domain: "stay", brief });
        return {
          domain: "stay",
          summary: "stay",
          options: [{ id: "stay-1", title: "Hakata anchor" }],
          warnings: [],
          missingInfo: [],
          evidence: ["Stay anchor keeps cross-day transfers manageable."],
          assumptions: [],
          confidence: 0.7,
        };
      },
    },
    mobilitySpecialist: {
      async research(brief) {
        callLog.push({ domain: "mobility", brief });
        return {
          domain: "mobility",
          summary: "mobility",
          options: [{ id: "mobility-1", title: "Later train" }],
          warnings: [],
          missingInfo: [],
          evidence: ["Later departure reduces transfer pressure."],
          assumptions: [],
          confidence: 0.8,
        };
      },
    },
    experienceSpecialist: {
      async research(brief) {
        callLog.push({ domain: "experience", brief });
        return {
          domain: "experience",
          summary: "experience",
          options: [{ id: "exp-1", title: "Trim city block" }],
          warnings: [],
          missingInfo: [],
          evidence: ["Shorter city block preserves pacing."],
          assumptions: [],
          confidence: 0.75,
        };
      },
    },
  });

  const planningBrief = createPlanningBrief({
    mode: "cross_day_replan",
    originMessage: "Rebalance two days.",
    affectedDayIds: ["day-1", "day-2"],
    replanScope: "multi_day",
  });

  await graph.run({
    proposalId: "proposal-1",
    trip: {
      id: "trip-1",
      version: 2,
      days: [
        { id: "day-1", nodes: [{ id: "n1", type: "hotel", title: "Hotel A" }] },
        { id: "day-2", nodes: [{ id: "n2", type: "transport", title: "Train A" }] },
      ],
    },
    intent: {
      affectedDayIds: ["day-1", "day-2"],
    },
    graphRequest: createTripPlanningGraphRequest({
      runId: "run-specialist",
      userId: "user-1",
      tripId: "trip-1",
      mode: "cross_day_replan",
      planningBrief,
      tripSnapshot: {
        id: "trip-1",
        version: 2,
        days: [
          { id: "day-1", nodes: [{ id: "n1", type: "hotel", title: "Hotel A" }] },
          { id: "day-2", nodes: [{ id: "n2", type: "transport", title: "Train A" }] },
        ],
      },
      constraints: [],
      preferences: [],
    }),
  });

  assert.deepEqual(
    callLog.map((entry) => entry.domain),
    ["stay", "mobility", "experience"],
  );
  assert.equal(callLog[0].brief.mode, "cross_day_replan");
  assert.equal(callLog[0].brief.skeletonPlan.tripShape, "cross-day rebalance");
});

test("mergeCandidatesNode builds candidates from usable research outcomes", () => {
  const state = createTripPlanningGraphState({
    runId: "run-merge-1",
    mode: "initial_plan",
    planningBrief: { affectedDayIds: [] },
    skeletonPlan: { dayFrames: [{ dayId: "day-1", theme: "arrival" }] },
    stayOutcome: createResearchSuccess({
      domain: "stay",
      result: {
        domain: "stay",
        summary: "Keep Hakata as the anchor.",
        options: [{ id: "stay-1", title: "Hakata" }],
        warnings: [],
        missingInfo: [],
        evidence: ["Short commute burden."],
        assumptions: [],
        confidence: 0.8,
      },
    }),
    mobilityOutcome: {
      domain: "mobility",
      status: "failed",
      result: null,
      reason: "provider_timeout",
      retryable: true,
      errorCode: "timeout_error",
    },
    experienceOutcome: {
      domain: "experience",
      status: "degraded",
      result: {
        domain: "experience",
        summary: "Trim one city walk.",
        options: [{ id: "exp-1", title: "Shorter city walk" }],
        warnings: [],
        missingInfo: ["opening hours"],
        evidence: [],
        assumptions: [],
        confidence: 0.45,
      },
      reason: "low_confidence_or_missing_evidence",
      retryable: false,
      errorCode: null,
    },
  });

  const next = mergeCandidatesNode(state);

  assert.equal(next.mergedCandidates.length > 0, true);
  assert.equal(next.mergedCandidates[0].warnings.includes("mobility research unavailable"), true);
  assert.equal(next.mergedCandidates[0].missingInfo.includes("opening hours"), true);
  assert.equal(typeof next.mergedCandidates[0].score, "number");
});
