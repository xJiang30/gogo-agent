const { createResearchResult } = require("../contracts/specialist-research-contracts.js");
const { createDefaultResearchProvider } = require("../providers/llm-provider.js");

function createStaySpecialist(deps = {}) {
  const provider = deps.provider || createDefaultResearchProvider(deps);

  return {
    async research(brief) {
      const payload = await provider.generateResearch({
        domain: "stay",
        systemPrompt: "You are the stay specialist for a trip-planning agent. Return only JSON.",
        userPrompt: buildStayPrompt(brief),
      });

      return createResearchResult({
        domain: "stay",
        ...payload,
      });
    },
  };
}

function buildStayPrompt(brief) {
  return [
    "Analyze lodging strategy for this trip planning request.",
    "Focus on stay anchors, hotel-switch tradeoffs, and transfer convenience.",
    `Mode: ${brief.mode}`,
    `Max options: ${brief.maxOptions || 3}`,
    `Planning brief: ${JSON.stringify(brief.planningBrief)}`,
    `Skeleton plan: ${JSON.stringify(brief.skeletonPlan)}`,
    `Trip snapshot: ${JSON.stringify(brief.tripSnapshot)}`,
    `Constraints: ${JSON.stringify(brief.constraints || [])}`,
    "Return JSON with fields: summary, options, warnings, missingInfo, evidence, assumptions, confidence.",
  ].join("\n");
}

module.exports = {
  createStaySpecialist,
};
