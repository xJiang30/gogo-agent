function classifyProviderFailure(error) {
  if (!error) {
    return {
      action: "fail",
      reason: "unknown_provider_failure",
      retryable: false,
      errorCode: null,
    };
  }

  if (error.code === "config_error") {
    return {
      action: "fail_fast",
      reason: "provider_misconfigured",
      retryable: false,
      errorCode: error.code,
    };
  }

  if (error.code === "timeout_error" || error.code === "network_error") {
    return {
      action: "retry",
      reason: "provider_timeout",
      retryable: true,
      errorCode: error.code,
    };
  }

  if (error.code === "provider_http_error" && error.retryable) {
    return {
      action: "retry",
      reason: "provider_transient_http",
      retryable: true,
      errorCode: error.code,
    };
  }

  if (error.code === "provider_response_error") {
    return {
      action: "fail",
      reason: "provider_untrusted_response",
      retryable: false,
      errorCode: error.code,
    };
  }

  return {
    action: error.retryable ? "retry" : "fail",
    reason: error.retryable ? "provider_transient_unknown" : "provider_hard_failure",
    retryable: Boolean(error.retryable),
    errorCode: error.code ?? null,
  };
}

module.exports = {
  classifyProviderFailure,
};
