const test = require("node:test");
const assert = require("node:assert/strict");

const {
  createPlanningBrief,
  createTripPlanningGraphRequest,
  createInitialGraphState,
} = require("../src/agent/contracts/planning-brief-and-graph-request-contracts.js");
const {
  createPlanCandidate,
  createTripPlanningGraphState,
} = require("../src/agent/contracts/trip-planning-graph-state-contracts.js");
const { LlmProviderError } = require("../src/agent/providers/provider-errors.js");
const { createTripPlanningGraphV2 } = require("../src/agent/graphs/trip-planning-graph-v2.js");
const { validateCandidatesNode } = require("../src/agent/graphs/nodes/validate-candidates-node.js");
const { finalizeOutputNode } = require("../src/agent/graphs/nodes/finalize-output-node.js");
const { createFakeResearchProvider } = require("./helpers/fake-research-provider.js");

function createTrip() {
  return {
    id: "trip-1",
    version: 7,
    days: [
      {
        id: "day-1",
        nodes: [
          { id: "hotel-1", type: "hotel", title: "Hotel Vista Hakata", location: "Hakata" },
          { id: "meal-1", type: "meal", title: "Ramen Dinner", location: "Tenjin" },
        ],
      },
      {
        id: "day-2",
        nodes: [
          { id: "train-1", type: "transport", title: "Yufuin no Mori", location: "Hakata -> Yufuin" },
        ],
      },
    ],
  };
}

function createCrossDayGraphRequest() {
  const planningBrief = createPlanningBrief({
    mode: "cross_day_replan",
    originMessage: "Move the Yufuin day later and rebalance the stay.",
    affectedDayIds: ["day-1", "day-2"],
    replanScope: "multi_day",
  });

  return {
    proposalId: "proposal-graph-test",
    trip: createTrip(),
    intent: {
      affectedDayIds: ["day-1", "day-2"],
    },
    graphRequest: createTripPlanningGraphRequest({
      runId: "run-graph-test",
      userId: "user-1",
      tripId: "trip-1",
      mode: "cross_day_replan",
      planningBrief,
      tripSnapshot: createTrip(),
      constraints: [],
      preferences: [],
    }),
  };
}

test("createInitialGraphState seeds the minimal graph state contract", () => {
  const planningBrief = createPlanningBrief({
    mode: "cross_day_replan",
    originMessage: "Move the Yufuin day later and rebalance the stay.",
    affectedDayIds: ["day-1", "day-2"],
    replanScope: "multi_day",
  });

  const request = createTripPlanningGraphRequest({
    runId: "run-1",
    userId: "user-1",
    tripId: "trip-1",
    mode: "cross_day_replan",
    planningBrief,
    tripSnapshot: createTrip(),
    constraints: [],
    preferences: [],
  });

  const state = createInitialGraphState(request);

  assert.equal(state.runId, "run-1");
  assert.equal(state.mode, "cross_day_replan");
  assert.equal(state.finalTripProposal, null);
  assert.deepEqual(state.mergedCandidates, []);
  assert.equal(state.status, "running");
});

test("TripPlanningGraphV2 runs the explicit node chain and returns a TripProposal for cross-day replan", async () => {
  const graph = createTripPlanningGraphV2({
    researchProvider: createFakeResearchProvider(),
  });
  const planningBrief = createPlanningBrief({
    mode: "cross_day_replan",
    originMessage: "Move the Yufuin day later and rebalance the stay.",
    affectedDayIds: ["day-1", "day-2"],
    replanScope: "multi_day",
  });

  const result = await graph.run({
    proposalId: "proposal-graph-1",
    trip: createTrip(),
    intent: {
      affectedDayIds: ["day-1", "day-2"],
    },
    graphRequest: createTripPlanningGraphRequest({
      runId: "run-2",
      userId: "user-1",
      tripId: "trip-1",
      mode: "cross_day_replan",
      planningBrief,
      tripSnapshot: createTrip(),
      constraints: [],
      preferences: [],
    }),
  });

  assert.equal(result.kind, "proposal");
  assert.equal(result.proposal.scope, "trip");
  assert.equal(result.trace.at(-1).node, "finalize_output_node");
  assert.deepEqual(result.trace.map((entry) => entry.node), [
    "skeleton_planning_node",
    "stay_research_node",
    "mobility_research_node",
    "experience_research_node",
    "merge_candidates_node",
    "validate_candidates_node",
    "finalize_output_node",
  ]);
});

test("TripPlanningGraphV2 returns RecommendationSet for initial_plan mode", async () => {
  const graph = createTripPlanningGraphV2({
    researchProvider: createFakeResearchProvider(),
  });
  const planningBrief = createPlanningBrief({
    mode: "initial_plan",
    originMessage: "Plan a relaxed 5-day Kyushu trip.",
    destinationCandidates: ["Kyushu"],
  });

  const result = await graph.run({
    proposalId: "proposal-graph-2",
    trip: createTrip(),
    intent: {
      affectedDayIds: [],
    },
    graphRequest: createTripPlanningGraphRequest({
      runId: "run-3",
      userId: "user-1",
      tripId: null,
      mode: "initial_plan",
      planningBrief,
      tripSnapshot: null,
      constraints: [],
      preferences: [],
    }),
  });

  assert.equal(result.kind, "recommendation_set");
  assert.equal(result.recommendationSet.recommendations.length, 3);
  assert.ok(result.recommendationSet.recommendations[0].summary);
  assert.ok(result.recommendationSet.recommendations[0].stayPlan.anchorArea);
  assert.ok(result.recommendationSet.recommendations[0].mobilityPlan.dayTrip.destination);
  assert.ok(result.recommendationSet.recommendations[0].foodPlan.mustTry.length > 0);
  assert.ok(result.recommendationSet.recommendations[0].dayPlans.length > 0);
  assert.ok(result.recommendationSet.recommendations[0].dayPlans[0].blocks.length > 0);
  assert.ok(result.recommendationSet.recommendations[0].evidence.length > 0);
  assert.notEqual(result.recommendationSet.recommendations[0].title, "Relaxed Onsen");
  assert.equal(result.trace.at(-1).node, "finalize_output_node");
});

test("TripPlanningGraphV2 marks mobility research as degraded when evidence is missing", async () => {
  const graph = createTripPlanningGraphV2({
    staySpecialist: {
      async research() {
        return {
          domain: "stay",
          summary: "Stay anchor is workable.",
          options: [{ id: "stay-1", title: "Keep Hakata" }],
          warnings: [],
          missingInfo: [],
          evidence: ["Short commute burden."],
          assumptions: [],
          confidence: 0.8,
        };
      },
    },
    mobilitySpecialist: {
      async research() {
        return {
          domain: "mobility",
          summary: "Mobility is only partially known.",
          options: [{ id: "mobility-1", title: "Later train" }],
          warnings: [],
          missingInfo: ["live timetable"],
          evidence: [],
          assumptions: [],
          confidence: 0.45,
        };
      },
    },
    experienceSpecialist: {
      async research() {
        return {
          domain: "experience",
          summary: "Trim one city block.",
          options: [{ id: "experience-1", title: "Shorter city walk" }],
          warnings: [],
          missingInfo: [],
          evidence: ["Reduces cross-day pressure."],
          assumptions: [],
          confidence: 0.75,
        };
      },
    },
  });

  await graph.run(createCrossDayGraphRequest());

  assert.equal(graph.getLastState().mobilityOutcome.status, "degraded");
});

test("TripPlanningGraphV2 returns a graph_error when a retryable specialist failure blocks the run", async () => {
  const graph = createTripPlanningGraphV2({
    staySpecialist: {
      async research() {
        return {
          domain: "stay",
          summary: "Stay anchor is workable.",
          options: [{ id: "stay-1", title: "Keep Hakata" }],
          warnings: [],
          missingInfo: [],
          evidence: ["Short commute burden."],
          assumptions: [],
          confidence: 0.8,
        };
      },
    },
    mobilitySpecialist: {
      async research() {
        throw new LlmProviderError({
          code: "timeout_error",
          message: "slow",
          retryable: true,
          status: 429,
        });
      },
    },
    experienceSpecialist: {
      async research() {
        return {
          domain: "experience",
          summary: "Trim one city block.",
          options: [{ id: "experience-1", title: "Shorter city walk" }],
          warnings: [],
          missingInfo: [],
          evidence: ["Reduces cross-day pressure."],
          assumptions: [],
          confidence: 0.75,
        };
      },
    },
  });

  const result = await graph.run(createCrossDayGraphRequest());

  assert.equal(result.kind, "graph_error");
  assert.equal(result.graphError.decision, "retry_later");
  assert.deepEqual(result.graphError.failedDomains, ["mobility"]);
});

test("validateCandidatesNode fails candidates with no evidence and low score", () => {
  const state = createTripPlanningGraphState({
    runId: "run-validate-1",
    mode: "cross_day_replan",
    planningBrief: { affectedDayIds: ["day-1", "day-2"] },
    mergedCandidates: [
      createPlanCandidate({
        candidateId: "c1",
        title: "weak",
        theme: "repair",
        summary: "weak",
        score: 0.2,
        evidence: [],
        warnings: ["mobility research unavailable"],
        missingInfo: ["live timetable"],
      }),
    ],
  });

  const next = validateCandidatesNode(state);
  assert.equal(next.validationResult.overallStatus, "fail");
  assert.deepEqual(next.validationResult.candidateResults[0].reasons, [
    "missing_evidence",
    "low_score",
  ]);
});

test("finalizeOutputNode chooses the highest-scoring passing candidate", () => {
  const trip = createTrip();
  const state = createTripPlanningGraphState({
    runId: "run-finalize-1",
    tripId: trip.id,
    mode: "cross_day_replan",
    planningBrief: { affectedDayIds: ["day-1", "day-2"] },
    mergedCandidates: [
      createPlanCandidate({
        candidateId: "weak",
        title: "Weak repair",
        theme: "repair",
        summary: "Weak summary",
        score: 0.6,
        evidence: ["thin support"],
        warnings: ["mobility research unavailable"],
        reasons: ["Weak option"],
      }),
      createPlanCandidate({
        candidateId: "strong",
        title: "Strong repair",
        theme: "repair",
        summary: "Rebalance stay anchor and push the Yufuin departure later.",
        score: 1.9,
        evidence: ["Stay anchor reduces commute burden.", "Later departure lowers pressure."],
        warnings: [],
        reasons: ["Cross-day repair needed", "Built from currently usable research outputs"],
        stayChoices: [{ id: "stay-1", title: "Keep Hakata" }],
        mobilityChoices: [{ id: "mobility-1", title: "Later train" }],
        experienceChoices: [{ id: "experience-1", title: "Shorter city walk" }],
      }),
    ],
    validationResult: {
      candidateResults: [
        { candidateId: "weak", status: "fail", reasons: ["low_score"] },
        { candidateId: "strong", status: "pass", reasons: [] },
      ],
      overallStatus: "pass",
    },
  });

  const result = finalizeOutputNode(state, "proposal-finalize-1", trip);
  assert.equal(
    result.finalTripProposal.summary,
    "Rebalance stay anchor and push the Yufuin departure later.",
  );
  assert.deepEqual(result.finalTripProposal.reasons, [
    "Cross-day repair needed",
    "Built from currently usable research outputs",
  ]);
});
