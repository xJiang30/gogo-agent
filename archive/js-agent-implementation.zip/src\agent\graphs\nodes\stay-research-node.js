const { createResearchBrief } = require("../../contracts/specialist-research-contracts.js");
const { runResearchStep } = require("./run-research-step.js");

async function stayResearchNode(state, deps) {
  const brief = createResearchBrief({
    briefId: `${state.runId}-stay`,
    domain: "stay",
    mode: state.mode,
    planningBrief: state.planningBrief,
    skeletonPlan: state.skeletonPlan,
    tripSnapshot: state.tripSnapshot,
    constraints: [],
    maxOptions: 3,
  });

  const { outcome, graphError } = await runResearchStep({
    domain: "stay",
    brief,
    specialist: deps.staySpecialist,
    classifyFailure: deps.classifyProviderFailure,
  });

  return {
    ...state,
    stayOutcome: outcome,
    stayResult: outcome.result,
    graphError: graphError || state.graphError,
    trace: state.trace.concat({ node: "stay_research_node", status: outcome.status }),
  };
}

module.exports = {
  stayResearchNode,
};
