const fs = require("node:fs");
const path = require("node:path");

const args = process.argv.slice(2);
const timeoutMs = readNumberArg("--timeout", 60000);
const noJsonMode = args.includes("--no-json-mode");
const message = readTextArg(
  "--message",
  'Return JSON only: {"summary":"ok","options":[],"warnings":[],"missingInfo":[],"evidence":["probe"],"assumptions":[],"confidence":0.9}',
);

async function main() {
  loadDotEnv(path.join(__dirname, "..", ".env"));

  const config = {
    apiKey: process.env.LLM_API_KEY,
    baseUrl: process.env.LLM_API_BASE,
    modelName: process.env.LLM_MODEL_NAME,
  };

  printConfig(config);
  validateConfig(config);

  const url = joinUrl(config.baseUrl, "/chat/completions");
  const body = {
    model: config.modelName,
    messages: [
      {
        role: "system",
        content: noJsonMode
          ? "You are a concise assistant."
          : "You are a JSON-only API probe. Return valid JSON only.",
      },
      { role: "user", content: message },
    ],
  };

  if (!noJsonMode) {
    body.response_format = { type: "json_object" };
  }

  console.log("\nRequest");
  console.log("--------------------------------");
  console.log(`POST ${url}`);
  console.log(`timeoutMs: ${timeoutMs}`);
  console.log(`json mode: ${noJsonMode ? "off" : "on"}`);

  const startedAt = Date.now();
  try {
    const response = await withTimeout(
      fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.apiKey}`,
        },
        body: JSON.stringify(body),
      }),
      timeoutMs,
    );

    const elapsedMs = Date.now() - startedAt;
    const text = await response.text();

    console.log("\nResponse");
    console.log("--------------------------------");
    console.log(`status: ${response.status} ${response.statusText}`);
    console.log(`elapsedMs: ${elapsedMs}`);
    console.log(`body preview: ${preview(text)}`);

    if (!response.ok) {
      process.exitCode = 1;
      return;
    }

    const payload = safeParseJson(text);
    const content = payload?.choices?.[0]?.message?.content;
    console.log("\nModel content");
    console.log("--------------------------------");
    console.log(preview(typeof content === "string" ? content : JSON.stringify(content)));

    if (!content) {
      process.exitCode = 1;
    }
  } catch (error) {
    const elapsedMs = Date.now() - startedAt;
    console.log("\nProbe failed");
    console.log("--------------------------------");
    console.log(`elapsedMs: ${elapsedMs}`);
    console.log(error && error.stack ? error.stack : String(error));
    process.exitCode = 1;
  }
}

function printConfig(config) {
  console.log("Qwen API probe");
  console.log("--------------------------------");
  console.log(`LLM_API_BASE: ${config.baseUrl || "MISSING"}`);
  console.log(`LLM_MODEL_NAME: ${config.modelName || "MISSING"}`);
  console.log(
    `LLM_API_KEY: ${config.apiKey ? `present (${config.apiKey.length} chars)` : "MISSING"}`,
  );
}

function validateConfig(config) {
  const missing = [];
  if (!config.apiKey) missing.push("LLM_API_KEY");
  if (!config.baseUrl) missing.push("LLM_API_BASE");
  if (!config.modelName) missing.push("LLM_MODEL_NAME");

  if (missing.length) {
    throw new Error(`Missing required .env values: ${missing.join(", ")}`);
  }
}

function loadDotEnv(envPath) {
  if (!fs.existsSync(envPath)) {
    return;
  }

  const lines = fs.readFileSync(envPath, "utf8").split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) {
      continue;
    }

    const separatorIndex = trimmed.indexOf("=");
    if (separatorIndex < 0) {
      continue;
    }

    const key = trimmed.slice(0, separatorIndex).trim();
    const value = trimmed.slice(separatorIndex + 1).trim();
    if (key && !process.env[key]) {
      process.env[key] = value;
    }
  }
}

function joinUrl(baseUrl, urlPath) {
  return `${String(baseUrl || "").replace(/\/+$/, "")}${urlPath}`;
}

function withTimeout(promise, delayMs) {
  let timeoutId;
  const timeoutPromise = new Promise((_, reject) => {
    timeoutId = setTimeout(() => {
      const error = new Error(`Request timed out after ${delayMs}ms`);
      error.code = "timeout_error";
      reject(error);
    }, delayMs);
  });

  return Promise.race([promise, timeoutPromise]).finally(() => {
    clearTimeout(timeoutId);
  });
}

function safeParseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function preview(text, maxLength = 1200) {
  if (!text) {
    return "";
  }

  const compact = String(text).replace(/\s+/g, " ").trim();
  return compact.length > maxLength ? `${compact.slice(0, maxLength)}...` : compact;
}

function readNumberArg(name, defaultValue) {
  const index = args.indexOf(name);
  if (index < 0 || !args[index + 1]) {
    return defaultValue;
  }

  const value = Number(args[index + 1]);
  return Number.isFinite(value) && value > 0 ? value : defaultValue;
}

function readTextArg(name, defaultValue) {
  const index = args.indexOf(name);
  return index >= 0 && args[index + 1] ? args[index + 1] : defaultValue;
}

main();
