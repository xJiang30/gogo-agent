const test = require("node:test");
const assert = require("node:assert/strict");

const {
  createAgentRunAccepted,
  createRunMetadata,
  createRunEvent,
  createNodeStartedEvent,
  createNodeCompletedEvent,
  createRecommendationReadyEvent,
  createProposalReadyEvent,
  createRunCompletedEvent,
} = require("../src/application/contracts/runs.js");
const { createProposalService } = require("../src/agent/proposal-service.js");
const { createTripProposal } = require("../src/agent/contracts/routing-and-proposal-contracts.js");

test("run contract factories create stable run metadata and typed events", () => {
  const run = createRunMetadata({
    runId: "run-1",
    mode: "initial_plan",
    userId: "user-1",
    conversationId: "conv-1",
  });

  const accepted = createAgentRunAccepted({
    run,
    output: { kind: "recommendation_set", recommendationSet: { type: "recommendation_set", recommendations: [] } },
  });

  const events = [
    createRunEvent({ eventId: "event-1", runId: "run-1", type: "run.started", payload: { mode: "initial_plan" } }),
    createNodeStartedEvent({ eventId: "event-2", runId: "run-1", node: "skeleton_planning_node" }),
    createNodeCompletedEvent({ eventId: "event-3", runId: "run-1", node: "skeleton_planning_node" }),
    createRecommendationReadyEvent({ eventId: "event-4", runId: "run-1", recommendationSet: { type: "recommendation_set", recommendations: [] } }),
    createProposalReadyEvent({ eventId: "event-5", runId: "run-1", proposal: { proposalId: "proposal-1" } }),
    createRunCompletedEvent({ eventId: "event-6", runId: "run-1" }),
  ];

  assert.equal(run.runId, "run-1");
  assert.equal(accepted.kind, "agent_run_accepted");
  assert.deepEqual(
    events.map((event) => event.type),
    [
      "run.started",
      "run.node.started",
      "run.node.completed",
      "run.recommendation.ready",
      "run.proposal.ready",
      "run.completed",
    ],
  );
});

test("ProposalService enforces allowed state transitions and records history", () => {
  const proposalService = createProposalService();
  const proposal = createTripProposal({
    proposalId: "proposal-1",
    tripId: "trip-1",
    baseVersion: 5,
    scope: "node",
    title: "Replace hotel",
    summary: "Switch to cheaper hotel",
    reasons: ["Lower price"],
    warnings: [],
    operations: [],
    impact: { affectedDayIds: ["day-2"], requiresRecalcSegmentIds: [] },
    evidence: [],
  });

  const persisted = proposalService.persistProposal(proposal, { currentTripVersion: 5 });
  const accepted = proposalService.updateProposalStatus("proposal-1", "accepted");
  const invalidRollback = proposalService.updateProposalStatus("proposal-1", "pending");
  const history = proposalService.getProposalHistory("proposal-1");

  assert.equal(persisted.status, "pending");
  assert.equal(accepted.status, "accepted");
  assert.equal(invalidRollback, null);
  assert.deepEqual(
    history.map((entry) => entry.toStatus),
    ["pending", "accepted"],
  );
});

test("ProposalService starts stale proposals in conflicted state and rejects illegal transitions", () => {
  const proposalService = createProposalService();
  const stale = createTripProposal({
    proposalId: "proposal-2",
    tripId: "trip-1",
    baseVersion: 4,
    scope: "trip",
    title: "Cross-day replan",
    summary: "Rebalance two days",
    reasons: ["Schedule pressure"],
    warnings: [],
    operations: [],
    impact: { affectedDayIds: ["day-2", "day-3"], requiresRecalcSegmentIds: [] },
    evidence: [],
  });

  const persisted = proposalService.persistProposal(stale, { currentTripVersion: 5 });
  const accepted = proposalService.updateProposalStatus("proposal-2", "accepted");

  assert.equal(persisted.status, "conflicted");
  assert.equal(accepted, null);
});
