const EscalationDecision = Object.freeze({
  DIRECT_ANSWER: "direct_answer",
  LIGHTWEIGHT_RESEARCH: "lightweight_research",
  LOCAL_PROPOSAL: "local_proposal",
  GRAPH_REPLAN: "graph_replan",
});

function createTripProposal(input) {
  return {
    proposalId: input.proposalId,
    tripId: input.tripId,
    baseVersion: input.baseVersion,
    scope: input.scope,
    title: input.title,
    summary: input.summary,
    reasons: input.reasons || [],
    warnings: input.warnings || [],
    operations: input.operations || [],
    impact: input.impact || { affectedDayIds: [], requiresRecalcSegmentIds: [] },
    evidence: input.evidence || [],
    status: input.status || "draft",
  };
}

module.exports = {
  EscalationDecision,
  createTripProposal,
};
