function createPlanCandidate(input) {
  return {
    candidateId: input.candidateId,
    title: input.title,
    theme: input.theme,
    summary: input.summary,
    dayFrames: input.dayFrames || [],
    stayChoices: input.stayChoices || [],
    mobilityChoices: input.mobilityChoices || [],
    experienceChoices: input.experienceChoices || [],
    stayPlan: input.stayPlan ?? null,
    mobilityPlan: input.mobilityPlan ?? null,
    foodPlan: input.foodPlan ?? null,
    dayPlans: input.dayPlans || [],
    bestFor: input.bestFor || [],
    tradeoffs: input.tradeoffs || [],
    reasons: input.reasons || [],
    risks: input.risks || [],
    score: input.score ?? 0,
    evidence: input.evidence || [],
    warnings: input.warnings || [],
    missingInfo: input.missingInfo || [],
  };
}

function createTripPlanningGraphState(input) {
  return {
    runId: input.runId,
    tripId: input.tripId ?? null,
    mode: input.mode,
    planningBrief: input.planningBrief,
    tripSnapshot: input.tripSnapshot ?? null,
    skeletonPlan: input.skeletonPlan ?? null,
    stayOutcome: input.stayOutcome ?? null,
    mobilityOutcome: input.mobilityOutcome ?? null,
    experienceOutcome: input.experienceOutcome ?? null,
    mergedCandidates: input.mergedCandidates || [],
    validationResult: input.validationResult ?? null,
    finalRecommendationSet: input.finalRecommendationSet ?? null,
    finalTripProposal: input.finalTripProposal ?? null,
    trace: input.trace || [],
    status: input.status || "running",
    error: input.error ?? null,
    graphError: input.graphError ?? null,
  };
}

module.exports = {
  createPlanCandidate,
  createTripPlanningGraphState,
};
