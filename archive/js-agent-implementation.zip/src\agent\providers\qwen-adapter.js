const { LlmProviderError } = require("./provider-errors.js");

function createQwenAdapter({ config, fetchImpl, timeoutMs = 15000, retry = {} } = {}) {
  const runtimeConfig = config || {};
  const fetcher = fetchImpl || globalThis.fetch;
  const retryOptions = {
    maxRetries: retry.maxRetries ?? 2,
    baseDelayMs: retry.baseDelayMs ?? 300,
    sleepImpl: retry.sleepImpl || defaultSleep,
  };

  return {
    async generateResearch(input) {
      validateConfig(runtimeConfig);

      let attempt = 0;
      while (attempt <= retryOptions.maxRetries) {
        try {
          const response = await withTimeout(
            fetcher(joinUrl(runtimeConfig.baseUrl, "/chat/completions"), {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${runtimeConfig.apiKey}`,
              },
              body: JSON.stringify({
                model: runtimeConfig.modelName,
                response_format: { type: "json_object" },
                messages: [
                  { role: "system", content: input.systemPrompt },
                  { role: "user", content: input.userPrompt },
                ],
              }),
            }),
            timeoutMs,
          );

          if (!response.ok) {
            throw await createHttpError(response);
          }

          const payload = await response.json();
          const content = payload?.choices?.[0]?.message?.content;
          const parsed = parseModelContent(content);
          return normalizeResearchPayload(parsed);
        } catch (error) {
          const typedError = normalizeError(error);
          if (!shouldRetry(typedError, attempt, retryOptions.maxRetries)) {
            throw typedError;
          }

          attempt += 1;
          await retryOptions.sleepImpl(retryOptions.baseDelayMs * attempt);
        }
      }

      throw new LlmProviderError({
        code: "network_error",
        message: "Qwen request exhausted retries",
        retryable: true,
      });
    },
  };
}

function joinUrl(baseUrl, path) {
  return `${String(baseUrl || "").replace(/\/+$/, "")}${path}`;
}

function parseModelContent(content) {
  if (typeof content === "string") {
    return safeParseJson(content);
  }

  if (Array.isArray(content)) {
    const text = content
      .map((entry) => entry.text || entry.content || "")
      .join("")
      .trim();
    return safeParseJson(text);
  }

  throw new LlmProviderError({
    code: "provider_response_error",
    message: "Qwen response did not contain a JSON message content",
    retryable: false,
  });
}

function normalizeResearchPayload(payload) {
  return {
    summary: payload.summary,
    options: payload.options || [],
    warnings: payload.warnings || [],
    missingInfo: payload.missingInfo || [],
    evidence: payload.evidence || [],
    assumptions: payload.assumptions || [],
    confidence: payload.confidence ?? null,
  };
}

function validateConfig(config) {
  if (!config.apiKey || !config.baseUrl || !config.modelName) {
    throw new LlmProviderError({
      code: "config_error",
      message: "Missing required LLM provider configuration",
      retryable: false,
    });
  }
}

async function createHttpError(response) {
  const status = response.status || null;
  let details = null;
  if (typeof response.text === "function") {
    details = await response.text();
  }

  return new LlmProviderError({
    code: "provider_http_error",
    message: `Qwen request failed with status ${status || "unknown"}`,
    retryable: isRetryableStatus(status),
    status,
    details,
  });
}

function normalizeError(error) {
  if (error instanceof LlmProviderError) {
    return error;
  }

  if (error?.code === "timeout_error") {
    return new LlmProviderError({
      code: "timeout_error",
      message: error.message,
      retryable: true,
      cause: error,
    });
  }

  if (error instanceof SyntaxError) {
    return new LlmProviderError({
      code: "provider_response_error",
      message: "Qwen returned invalid JSON content",
      retryable: false,
      cause: error,
    });
  }

  return new LlmProviderError({
    code: "network_error",
    message: error?.message || "Qwen request failed before receiving a response",
    retryable: true,
    cause: error,
  });
}

function shouldRetry(error, attempt, maxRetries) {
  return Boolean(error.retryable) && attempt < maxRetries;
}

function isRetryableStatus(status) {
  return status === 429 || (status >= 500 && status < 600);
}

function safeParseJson(input) {
  try {
    return JSON.parse(input);
  } catch (error) {
    throw new LlmProviderError({
      code: "provider_response_error",
      message: "Qwen returned invalid JSON content",
      retryable: false,
      cause: error,
    });
  }
}

function withTimeout(promise, timeoutMs) {
  if (!timeoutMs || timeoutMs <= 0) {
    return promise;
  }

  let timeoutId;
  const timeoutPromise = new Promise((_, reject) => {
    timeoutId = setTimeout(() => {
      const error = new Error(`Qwen request timed out after ${timeoutMs}ms`);
      error.code = "timeout_error";
      reject(error);
    }, timeoutMs);
  });

  return Promise.race([promise, timeoutPromise]).finally(() => {
    clearTimeout(timeoutId);
  });
}

function defaultSleep(delayMs) {
  return new Promise((resolve) => setTimeout(resolve, delayMs));
}

module.exports = {
  createQwenAdapter,
};
