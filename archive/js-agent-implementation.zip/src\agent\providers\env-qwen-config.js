function createEnvQwenConfig(env = process.env) {
  return {
    apiKey: env.LLM_API_KEY,
    baseUrl: env.LLM_API_BASE,
    modelName: env.LLM_MODEL_NAME,
  };
}

module.exports = {
  createEnvQwenConfig,
};
