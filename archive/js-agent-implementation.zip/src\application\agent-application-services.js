const { createTravelAdvisor } = require("../agent/travel-advisor.js");
const { createProposalService } = require("../agent/proposal-service.js");
const { createProposalExecutor } = require("../agent/proposal-executor.js");
const { createTripPlanningGraphV2 } = require("../agent/graphs/trip-planning-graph-v2.js");
const { createLightweightFlows } = require("../agent/lightweight-flows.js");
const { createTravelAdvisorRequest } = require("../agent/contracts/travel-advisor-io-contracts.js");
const {
  createAgentRunAccepted,
  createRunMetadata,
} = require("./contracts/runs.js");

function createAgentApplicationServices(deps = {}) {
  const proposalService = deps.proposalService || createProposalService();
  const advisor =
    deps.advisor ||
    createTravelAdvisor({
      proposalService,
      graph: deps.graph || createTripPlanningGraphV2(),
      lightweightFlows: deps.lightweightFlows || createLightweightFlows(),
      executor: deps.executor || createProposalExecutor(),
      planningBriefBuilder: deps.planningBriefBuilder,
      escalationPolicy: deps.escalationPolicy,
    });

  return {
    async startInitialPlanRun(command) {
      const request = createTravelAdvisorRequest({
        userId: command.userId,
        conversationId: command.conversationId,
        userMessage: command.userMessage,
        trip: null,
        intent: {
          kind: "initial_plan",
          scope: "trip",
          affectedDayIds: [],
          canCloseLocally: false,
          destinationCandidates: [],
        },
      });

      const output = await advisor.handleRequest(request);
      return createAgentRunAccepted({
        run: createRunMetadata({
          runId: createRunId("initial-plan"),
          mode: "initial_plan",
          conversationId: command.conversationId,
          userId: command.userId,
        }),
        output,
      });
    },

    async handleDiscussionTurn(command) {
      const request = createTravelAdvisorRequest({
        userId: command.userId,
        conversationId: command.discussionId,
        userMessage: command.userMessage,
        trip: command.trip,
        intent: command.intent,
      });

      const output = await advisor.handleRequest(request);
      return createAgentRunAccepted({
        run: createRunMetadata({
          runId: createRunId("discussion"),
          mode: "discussion_turn",
          conversationId: command.discussionId,
          discussionId: command.discussionId,
          tripId: command.trip.id,
          userId: command.userId,
        }),
        output,
      });
    },

    async executeProposal(command) {
      return advisor.executeProposal({
        trip: command.trip,
        proposalId: command.proposalId,
      });
    },

    setProposalStatus(proposalId, status) {
      return proposalService.updateProposalStatus(proposalId, status);
    },
  };
}

function createRunId(prefix) {
  return `${prefix}-${Date.now()}`;
}

module.exports = {
  createAgentApplicationServices,
};
