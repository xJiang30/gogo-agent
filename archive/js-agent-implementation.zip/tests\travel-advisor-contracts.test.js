const test = require("node:test");
const assert = require("node:assert/strict");

const {
  createTravelAdvisorRequest,
  createAnswerResponse,
  createProposalResponse,
  createRecommendationSetResponse,
  createExecutionRequest,
  createExecutionResponse,
} = require("../src/agent/contracts/travel-advisor-io-contracts.js");
const { createTravelAdvisor } = require("../src/agent/travel-advisor.js");
const { createProposalService } = require("../src/agent/proposal-service.js");
const { createProposalExecutor } = require("../src/agent/proposal-executor.js");
const { createTripPlanningGraphV2 } = require("../src/agent/graphs/trip-planning-graph-v2.js");
const { createLightweightFlows } = require("../src/agent/lightweight-flows.js");
const { createFakeResearchProvider } = require("./helpers/fake-research-provider.js");

function createTrip() {
  return {
    id: "trip-1",
    version: 3,
    days: [
      {
        id: "day-2",
        nodes: [{ id: "hotel-1", type: "hotel", title: "Hotel Vista Hakata" }],
      },
    ],
  };
}

test("TravelAdvisor contract factories create stable request and response shapes", () => {
  const request = createTravelAdvisorRequest({
    userId: "user-1",
    conversationId: "conv-1",
    userMessage: "Why this hotel?",
    trip: createTrip(),
    intent: { kind: "ask", scope: "node", nodeId: "hotel-1", affectedDayIds: ["day-2"] },
  });

  const answer = createAnswerResponse({
    routing: { decision: "direct_answer", reasons: ["Can answer directly"] },
    planningBrief: { mode: "initial_plan" },
    text: "Because it is near Hakata Station.",
  });

  const proposal = createProposalResponse({
    routing: { decision: "local_proposal", reasons: ["Local change"] },
    planningBrief: { mode: "cross_day_replan" },
    proposal: { proposalId: "proposal-1", status: "pending" },
  });

  const recommendationSet = createRecommendationSetResponse({
    routing: { decision: "graph_replan", reasons: ["Initial planning path"] },
    planningBrief: { mode: "initial_plan" },
    recommendationSet: { type: "recommendation_set", recommendations: [] },
  });

  const executionRequest = createExecutionRequest({
    trip: createTrip(),
    proposalId: "proposal-1",
  });

  const executionResponse = createExecutionResponse({
    trip: { id: "trip-1", version: 4, days: [] },
    decisionLog: { proposalId: "proposal-1" },
  });

  assert.equal(request.userId, "user-1");
  assert.equal(answer.kind, "answer");
  assert.equal(proposal.kind, "proposal");
  assert.equal(recommendationSet.kind, "recommendation_set");
  assert.equal(executionRequest.proposalId, "proposal-1");
  assert.equal(executionResponse.trip.version, 4);
});

test("TravelAdvisor returns contract-shaped responses for answer, proposal, and execution paths", async () => {
  const proposalService = createProposalService();
  const advisor = createTravelAdvisor({
    proposalService,
    graph: createTripPlanningGraphV2({
      researchProvider: createFakeResearchProvider(),
    }),
    lightweightFlows: createLightweightFlows(),
    executor: createProposalExecutor(),
  });

  const answerResult = await advisor.handleRequest(
    createTravelAdvisorRequest({
      userId: "user-1",
      conversationId: "conv-1",
      userMessage: "Why this hotel?",
      trip: createTrip(),
      intent: { kind: "ask", scope: "node", nodeId: "hotel-1", affectedDayIds: ["day-2"] },
    }),
  );

  const proposalResult = await advisor.handleRequest(
    createTravelAdvisorRequest({
      userId: "user-1",
      conversationId: "conv-2",
      userMessage: "Replace this hotel with a cheaper one.",
      trip: createTrip(),
      intent: {
        kind: "replace",
        scope: "node",
        nodeId: "hotel-1",
        replacementType: "hotel",
        affectedDayIds: ["day-2"],
      },
    }),
  );

  proposalService.updateProposalStatus(proposalResult.proposal.proposalId, "accepted");

  const executionResult = await advisor.executeProposal(
    createExecutionRequest({
      trip: createTrip(),
      proposalId: proposalResult.proposal.proposalId,
    }),
  );

  assert.equal(answerResult.kind, "answer");
  assert.equal(proposalResult.kind, "proposal");
  assert.ok(proposalResult.proposal.proposalId);
  assert.equal(executionResult.trip.version, 4);
  assert.equal(executionResult.decisionLog.proposalId, proposalResult.proposal.proposalId);
});
