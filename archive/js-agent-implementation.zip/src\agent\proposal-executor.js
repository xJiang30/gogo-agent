function createProposalExecutor() {
  return {
    execute(trip, proposal) {
      if (proposal.status !== "accepted") {
        throw new Error("Only accepted proposals can be executed");
      }

      if (trip.version !== proposal.baseVersion) {
        throw new Error("Trip version mismatch");
      }

      const nextTrip = {
        ...trip,
        version: trip.version + 1,
        days: trip.days.map((day) => ({
          ...day,
          nodes: day.nodes.map((node) => ({ ...node })),
        })),
      };

      for (const operation of proposal.operations) {
        if (operation.type === "ReplaceNode") {
          const day = nextTrip.days.find((item) => item.id === operation.dayId);
          if (!day) continue;
          const index = day.nodes.findIndex((node) => node.id === operation.nodeId);
          if (index === -1) continue;
          day.nodes[index] = {
            ...day.nodes[index],
            ...operation.replacement,
          };
        }

        if (operation.type === "UpdateNode") {
          const day = nextTrip.days.find((item) => item.id === operation.dayId);
          if (!day) continue;
          const node = day.nodes.find((item) => item.id === operation.nodeId);
          if (!node) continue;
          Object.assign(node, operation.patch);
        }
      }

      return {
        trip: nextTrip,
        decisionLog: {
          proposalId: proposal.proposalId,
          tripId: proposal.tripId,
          executedAt: new Date().toISOString(),
          operations: proposal.operations,
        },
      };
    },
  };
}

module.exports = {
  createProposalExecutor,
};
