function createResearchSuccess(input) {
  return {
    domain: input.domain,
    status: "success",
    result: input.result,
    reason: null,
    retryable: false,
    errorCode: null,
  };
}

function createResearchDegraded(input) {
  return {
    domain: input.domain,
    status: "degraded",
    result: input.result,
    reason: input.reason,
    retryable: false,
    errorCode: null,
  };
}

function createResearchFailure(input) {
  return {
    domain: input.domain,
    status: "failed",
    result: null,
    reason: input.reason,
    retryable: Boolean(input.retryable),
    errorCode: input.errorCode ?? null,
  };
}

function isResearchUsable(outcome) {
  return outcome?.status === "success" || outcome?.status === "degraded";
}

module.exports = {
  createResearchSuccess,
  createResearchDegraded,
  createResearchFailure,
  isResearchUsable,
};
