const test = require("node:test");
const assert = require("node:assert/strict");

const {
  EscalationDecision,
  decideEscalation,
  createTripProposal,
  createProposalService,
  executeAcceptedProposal,
} = require("../agent-runtime.js");

test("returns LOCAL_PROPOSAL for a single-node hotel replacement that closes locally", () => {
  const result = decideEscalation({
    affectedDayIds: ["day-2"],
    requiresStayReorder: false,
    requiresCrossCityRebuild: false,
    canCloseLocally: true,
    breaksMultiDayConstraints: false,
    intent: "replace_hotel",
  });

  assert.equal(result.decision, EscalationDecision.LOCAL_PROPOSAL);
  assert.deepEqual(result.affectedDayIds, ["day-2"]);
});

test("returns GRAPH_REPLAN when the request affects multiple days", () => {
  const result = decideEscalation({
    affectedDayIds: ["day-2", "day-3"],
    requiresStayReorder: true,
    requiresCrossCityRebuild: false,
    canCloseLocally: false,
    breaksMultiDayConstraints: true,
    intent: "replan_hotel_anchor",
  });

  assert.equal(result.decision, EscalationDecision.GRAPH_REPLAN);
  assert.match(result.reasons.join(" "), /multiple days/i);
});

test("persists a pending TripProposal and marks conflicts on stale version", () => {
  const proposalService = createProposalService();
  const proposal = createTripProposal({
    proposalId: "proposal-local-1",
    tripId: "trip-1",
    baseVersion: 3,
    scope: "node",
    title: "Replace hotel",
    summary: "Switch to a cheaper hotel near Hakata Station.",
    reasons: ["Lower price", "Keeps commute short"],
    warnings: [],
    operations: [
      {
        type: "ReplaceNode",
        dayId: "day-2",
        nodeId: "hotel-1",
        replacement: {
          id: "hotel-2",
          type: "hotel",
          title: "Budget Hakata Hotel",
          location: "Hakata Station",
        },
      },
    ],
    impact: {
      affectedDayIds: ["day-2"],
      requiresRecalcSegmentIds: ["seg-in", "seg-out"],
    },
    evidence: [],
  });

  const stored = proposalService.persistProposal(proposal, { currentTripVersion: 3 });
  const conflicted = proposalService.persistProposal(
    createTripProposal({
      ...proposal,
      proposalId: "proposal-local-2",
      baseVersion: 2,
    }),
    { currentTripVersion: 3 },
  );

  assert.equal(stored.status, "pending");
  assert.equal(proposalService.getProposal("proposal-local-1").status, "pending");
  assert.equal(conflicted.status, "conflicted");
});

test("executes an accepted proposal, replaces the targeted node, and increments trip version", () => {
  const trip = {
    id: "trip-1",
    version: 3,
    days: [
      {
        id: "day-2",
        nodes: [
          {
            id: "hotel-1",
            type: "hotel",
            title: "Hotel Vista Hakata",
            location: "Hakata",
          },
        ],
      },
    ],
  };

  const proposal = {
    ...createTripProposal({
      proposalId: "proposal-local-3",
      tripId: "trip-1",
      baseVersion: 3,
      scope: "node",
      title: "Replace hotel",
      summary: "Switch to a cheaper hotel near Hakata Station.",
      reasons: ["Lower price"],
      warnings: [],
      operations: [
        {
          type: "ReplaceNode",
          dayId: "day-2",
          nodeId: "hotel-1",
          replacement: {
            id: "hotel-2",
            type: "hotel",
            title: "Budget Hakata Hotel",
            location: "Hakata Station",
          },
        },
      ],
      impact: {
        affectedDayIds: ["day-2"],
        requiresRecalcSegmentIds: ["seg-in", "seg-out"],
      },
      evidence: [],
    }),
    status: "accepted",
  };

  const result = executeAcceptedProposal(trip, proposal);

  assert.equal(result.trip.version, 4);
  assert.equal(result.trip.days[0].nodes[0].title, "Budget Hakata Hotel");
  assert.equal(result.decisionLog.proposalId, "proposal-local-3");
});
