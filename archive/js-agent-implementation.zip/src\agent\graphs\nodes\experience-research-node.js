const { createResearchBrief } = require("../../contracts/specialist-research-contracts.js");
const { runResearchStep } = require("./run-research-step.js");

async function experienceResearchNode(state, deps) {
  const brief = createResearchBrief({
    briefId: `${state.runId}-experience`,
    domain: "experience",
    mode: state.mode,
    planningBrief: state.planningBrief,
    skeletonPlan: state.skeletonPlan,
    tripSnapshot: state.tripSnapshot,
    constraints: [],
    maxOptions: 3,
  });

  const { outcome, graphError } = await runResearchStep({
    domain: "experience",
    brief,
    specialist: deps.experienceSpecialist,
    classifyFailure: deps.classifyProviderFailure,
  });

  return {
    ...state,
    experienceOutcome: outcome,
    experienceResult: outcome.result,
    graphError: graphError || state.graphError,
    trace: state.trace.concat({ node: "experience_research_node", status: outcome.status }),
  };
}

module.exports = {
  experienceResearchNode,
};
